package server;

import server.logic.*;

import java.io.*;
import java.net.*;
import java.util.HashSet;
import java.util.Set;

/**
 * A Dungeon of Doom server. Allows multiple clients to play on a shared map, and with shared game logic.
 *
 * @author  Ben Hetherington
 * @version 1.1
 * @release 06/04/2016
 */
public class Server implements Runnable {

    private boolean loggingEnabled = false;

    private GameLogic logic = new GameLogic(this);
    private ServerSocket socket;
    private Set<ServerConnection> connections = new HashSet<>();

    /**
     * Constructs a server.
     *
     * @param port
     *      The port to use.
     * @param map
     *      The map to use.
     * @throws IOException
     *      Thrown if the server couldn't be started.
     */
    public Server(int port, Map map) throws IOException {
        logic.setMap(map);

        socket = new ServerSocket(port);
        Thread thread = new Thread(this);
        thread.setName("Server");
        thread.start();

        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                try {
                    Server.this.stop();
                } catch (IOException e) {
                    // Not a lot that we can do about this now.
                }
            }
        });
    }

    /**
     * @return
     *      This server's game logic object.
     */
    public GameLogic getLogic() {
        return logic;
    }

    /**
     * Logs the given message, if logging is enabled.
     *
     * @param message
     *      The message to log.
     */
    public synchronized void logMessage(String message) {
        if (loggingEnabled) {
            System.out.println(message);
        }
    }

    /**
     * Logs the given error, if logging is enabled.
     *
     * @param message
     *      The message to log.
     */
    public synchronized void logError(String message) {
        if (loggingEnabled) {
            System.err.println(message);
        }
    }

    /**
     * The main loop for the server. Accepts connections, and spawns new threads for each connection.
     */
    public void run() {
        while (!socket.isClosed() && logic.isGameRunning()) {
            try {
                Socket newClientSocket = socket.accept();
                ServerConnection connection = new ServerConnection(this, newClientSocket);
                connections.add(connection);
                new Thread(connection).start();

            } catch (IOException | TooManyPlayersException e) {
                logError("Connection couldn't be accepted:");
                logError(e.getLocalizedMessage());
            }
        }

        for (ServerConnection connection : connections) {
            try {
                connection.closeSocket();
            } catch (IOException e) {
                // Not a lot we can do about this
            }
        }
    }

    /**
     * Stops the server, by closing its socket.
     *
     * @throws IOException
     *      Thrown if there was an error stopping the server.
     */
    public void stop() throws IOException {
        if (!socket.isClosed()) {
            socket.close();
            logMessage("Stopping the server.");
        }
    }

}

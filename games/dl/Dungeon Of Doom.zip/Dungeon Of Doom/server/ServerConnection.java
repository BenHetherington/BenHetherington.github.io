package server;

import common.network.*;
import server.logic.*;
import common.Direction;

import java.io.*;
import java.net.Socket;
import java.util.*;

/**
 * Represents a server's connection to a client.
 * Allows the server to receive commands, and have them processed by GameLogic.
 *
 * @author  Ben Hetherington
 * @version 1.1
 * @release 06/04/2016
 */
public class ServerConnection implements Runnable {

    final private Server server;
    final private Socket socket;
    final private InputStream input;
    final private OutputStream output;
    final private Player player;

    private boolean eventsEnabled = true;
    private Queue<Byte> eventsBuffer = new ArrayDeque<>();

    /**
     * Constructor for a connection.
     *
     * @param server
     *      The server that the connection was made with.
     * @param socket
     *      The socket used to connect to the client.
     * @throws IOException
     *      Thrown if there's an error getting the socket's I/O streams.
     */
    public ServerConnection(Server server, Socket socket) throws IOException, TooManyPlayersException {
        this.server = server;
        this.socket = socket;
        input = socket.getInputStream();
        output = socket.getOutputStream();

        player = new Player(this);

        setEventsEnabled(false);
        server.logMessage("Player " + player.getPlayerID() + " has joined. " + socket);
        server.getLogic().addPlayer(player);

        sendBytes(new byte[] {player.getPlayerID()});
        setEventsEnabled(true);
    }

    /**
     * Parses a given command, and has the server's game logic process it.
     *
     * @param commandByte
     *      The entered command (received from the client).
     * @return
     *      The response from the game logic (to be sent to the client).
     */
    private Result parseCommand(byte commandByte) throws IOException {
        Commands command = Commands.valueOf(commandByte);

        if (command == null) {
            return Result.Fail;
        }

        switch (command) {
            case MoveUp:
            case MoveDown:
            case MoveLeft:
            case MoveRight:
                player.waitUntilReadyToMove();

                Direction direction = null;
                switch (command) {
                    case MoveUp:
                        direction = Direction.Up;
                        break;

                    case MoveDown:
                        direction = Direction.Down;
                        break;

                    case MoveLeft:
                        direction = Direction.Left;
                        break;

                    case MoveRight:
                        direction = Direction.Right;
                        break;
                }

                return server.getLogic().move(player, direction);

            case Pickup:
                return server.getLogic().pickup(player);

            case ChangeSprite:
                int characterID = input.read();
                int spriteID = input.read();

                if (characterID == -1 || spriteID == -1) {
                    throw new EOFException();
                }

                return server.getLogic().changeSprite(player, (byte)characterID, (byte)spriteID);

            case Quit:
                server.logMessage("Player " + player.getPlayerID() + " has left. " + socket);
                server.getLogic().removePlayer(player);
                return null; // No need to respond

            default:
                return Result.Fail;
        }
    }

    /**
     * Sends an event, using the given bytes.
     *
     * @param dataToSend
     *      The data to send.
     */
    public synchronized void sendEvent(byte[] dataToSend) {
        if (eventsEnabled) {
            sendBytes(dataToSend);
        } else {
            for (byte data : dataToSend) {
                eventsBuffer.add(data);
            }
        }
    }

    /**
     * Enables or disables events for this connection.
     *
     * @param enabled
     *      True if events should be enabled; false if they should be disabled.
     */
    public synchronized void setEventsEnabled(boolean enabled) {
        if (enabled && !eventsEnabled) {
            byte[] dataToSend = new byte[eventsBuffer.size()];

            for (int i = 0; i < dataToSend.length; i++) {
                dataToSend[i] = eventsBuffer.poll();
            }

            sendBytes(dataToSend);
        }

        eventsEnabled = enabled;
    }

    /**
     * Sends non-event data to the client.
     *
     * @param dataToSend
     *      The data to send to the client.
     */
    public synchronized void sendBytes(byte[] dataToSend) {
        try {
            synchronized (output) {
                output.write(dataToSend);
                output.flush();
            }

        } catch (IOException e) {
            server.logError("Couldn't send bytes to player:");
            server.logError(e.getLocalizedMessage());
            try {
                closeSocket();
            } catch (IOException e1) {
                // Not a lot we can do about this
            }
        }
    }

    /**
     * The main loop for a server connection. Gets commands from the user, and has them processed by the game logic,
     * and sends back the response.
     */
    public void run() {
        Thread.currentThread().setName("ServerConnection - ID: " + player.getPlayerID());

        try {
            while (socket.isConnected() && server.getLogic().isGameRunning() && server.getLogic().isPlayerInGame(player)) {
                int command = input.read();

                if (command != -1) {
                    Result result = parseCommand((byte)command);

                    setEventsEnabled(false);

                    if (result != null) {
                        sendBytes(new byte[] {result.value});
                    }

                    setEventsEnabled(true);

                } else {
                    throw new EOFException();
                }
            }

        } catch (IOException e) {
            server.logError("Player " + player.getPlayerID() + " connection error: " + e.getLocalizedMessage());

        } finally {
            try {
                server.getLogic().removePlayer(player);
                socket.close();

                if (!server.getLogic().isGameRunning()) {
                    server.stop();
                }

            } catch (IOException e) {
                server.logError("Cannot close socket or stop server: " + e.getLocalizedMessage());
            }
        }
    }

    /**
     * Closes this connection's socket.
     *
     * @throws IOException
     *      Thrown if the socket couldn't be closed.
     */
    public void closeSocket() throws IOException {
        socket.close();
    }

}

package server.logic;

/**
 * An exception that's thrown if a player can't be added to a game.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class TooManyPlayersException extends Exception {

    /**
     * {@inheritDoc}
     */
    public TooManyPlayersException() {
        super("Too many players are already connected.");
    }

}

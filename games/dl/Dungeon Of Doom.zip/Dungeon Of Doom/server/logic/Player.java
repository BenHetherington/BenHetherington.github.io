package server.logic;

import common.network.Events;
import server.ServerConnection;

import java.awt.Point;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Represents a player in the game.
 *
 * @author  Ben Hetherington
 * @version 1.1
 * @release 06/04/2016
 */
public class Player {

    final private static int MIN_MOVE_INTERVAL = 250;
    private static Queue<Byte> availablePlayerIDs;

    private ServerConnection connection;
    private byte playerID;
    private byte collectedGold = 0;
    private Point position = new Point();

    private byte visibleAreaRange = 5;
    private byte playerAlertRange = 7;
    private long lastMovementTime = 0;

    private byte cachedCharacter = 0;
    private byte cachedSprite = 0;

    protected Set<Player> knownNearbyPlayers = new HashSet<>();

    /**
     * Constructs a new player, and assigns them a unique player number.
     */
    public Player(ServerConnection connection) throws TooManyPlayersException {
        if (availablePlayerIDs == null) {
            setUpPlayerIDsQueue();
        }

        this.connection = connection;

        if (availablePlayerIDs.size() > 0) {
            playerID = availablePlayerIDs.poll();

        } else {
            throw new TooManyPlayersException();
        }
    }

    /**
     * @return
     *      The player's ID.
     */
    public byte getPlayerID() {
        return playerID;
    }

    /**
     * Adds the given amount of gold to the player's gold total.
     *
     * @param amount
     *      The amount of gold to be added.
     */
    public synchronized void collectGold(int amount) {
        collectedGold += amount;
    }

    /**
     * Sleeps the current thread until the player is allowed to move again.
     */
    public void waitUntilReadyToMove() {
        long currentTime = TimeUnit.NANOSECONDS.convert(System.nanoTime(), TimeUnit.MILLISECONDS);

        if (lastMovementTime + MIN_MOVE_INTERVAL > currentTime) {
            try {
                Thread.sleep(currentTime + MIN_MOVE_INTERVAL - lastMovementTime);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    /**
     * @return
     *      The amount of gold collected by the player.
     */
    public byte getCollectedGold() {
        return collectedGold;
    }

    /**
     * Sets the player's position on the map.
     * Should call waitUntilReadyToMove() before doing this.
     *
     * @param position
     *      The player's new position.
     */
    public void setPosition(Point position) {
        if (lastMovementTime + MIN_MOVE_INTERVAL > TimeUnit.NANOSECONDS.convert(System.nanoTime(), TimeUnit.MILLISECONDS)) {
            throw new RuntimeException("Tried to set the position too quickly. Must wait " + MIN_MOVE_INTERVAL + "ms between movements.");
        }

        this.position = position;
        lastMovementTime = System.nanoTime();
    }

    /**
     * @return
     *      The player's current position.
     */
    public Point getPosition() {
        return position;
    }

    /**
     * @return
     *      The player's player alert range.
     */
    public byte getPlayerAlertRange() {
        return playerAlertRange;
    }

    /**
     * @return
     *      The player's visible area range.
     */
    public byte getVisibleAreaRange() {
        return visibleAreaRange;
    }

    /**
     * Tests if this player should be alerted about another player.
     *
     * @param player
     *      The player to check
     * @return
     *      True if this player should know about the other player; false otherwise.
     */
    public boolean shouldKnowAbout(Player player) {
        Point myPosition = this.getPosition();
        Point otherPlayerPosition = player.getPosition();

        if (Math.abs(myPosition.x - otherPlayerPosition.x) < playerAlertRange / 2.0) {
            if (Math.abs(myPosition.y - otherPlayerPosition.y) < playerAlertRange / 2.0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Tests if this player can see the tile at the given position.
     *
     * @param tilePosition
     *      The tile position, relative to the entire map.
     * @return
     *      True if the player can see this tile; false otherwise.
     */
    public boolean canSee(Point tilePosition) {
        if (Math.abs(getPosition().x - tilePosition.x) < visibleAreaRange / 2.0) {
            if (Math.abs(getPosition().y - tilePosition.y) < visibleAreaRange / 2.0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Enables or disables events for this player.
     *
     * @param enabled
     *      True if events should be enabled; false if they should be disabled.
     */
    public void setEventsEnabled(boolean enabled) {
        connection.setEventsEnabled(enabled);
    }

    /**
     * Sends an event to the given player.
     *
     * @param event
     *      The event to send.
     * @param parameters
     *      The event's parameters, if necessary.
     */
    public void sendEvent(Events event, byte... parameters) {
        if (parameters == null) {
            parameters = new byte[0];
        }

        byte[] bytesToSend = new byte[parameters.length + 1];
        bytesToSend[0] = event.value;
        System.arraycopy(parameters, 0, bytesToSend, 1, parameters.length);

        connection.sendEvent(bytesToSend);
    }

    /**
     * @return
     *      The position of the player's top-left tile in their view, relative to the entire map.
     */
    public Point getOriginOfViewForVisibleArea() {
        return getOriginOfView(visibleAreaRange);
    }

    /**
     * @return
     *      The position of the player's top-left tile in their player alert range, relative to the entire map.
     */
    public Point getOriginOfViewForPlayerAlerts() {
        return getOriginOfView(playerAlertRange);
    }

    /**
     * Calculates the origin of the player's view, with the given range.
     *
     * @param range
     *      The range to use.
     * @return
     *      The top-left tile from the player's view.
     */
    private Point getOriginOfView(byte range) {
        return new Point(getPosition().x - (range / 2), getPosition().y - (range / 2));
    }

    /**
     * Gets the player's position, relative to the given origin.
     *
     * @param origin
     *      The origin to use.
     * @return
     *      The player's position, relative to the origin.
     */
    public Point getRelativePosition(Point origin) {
        return new Point(getPosition().x - origin.x, getPosition().y - origin.y);
    }

    /**
     * Sets the player's cached character.
     *
     * @param cachedCharacter
     *      The character to cache.
     */
    public void setCachedCharacter(byte cachedCharacter) {
        this.cachedCharacter = cachedCharacter;
    }

    /**
     * @return
     *      This player's cached character.
     */
    public byte getCachedCharacter() {
        return cachedCharacter;
    }

    /**
     * @return
     *      This player's cached sprite.
     */
    public byte getCachedSprite() {
        return cachedSprite;
    }

    /**
     * Sets the player's cached sprite.
     *
     * @param cachedSprite
     *      The sprite to cache.
     */
    public void setCachedSprite(byte cachedSprite) {
        this.cachedSprite = cachedSprite;
    }

    /**
     * Initialises the player ID queue.
     */
    private static void setUpPlayerIDsQueue() {
        availablePlayerIDs = new ArrayDeque<>();
        for (byte i = 0; i < Byte.MAX_VALUE; i++) {
            availablePlayerIDs.add(i);
        }
    }

    /**
     * Adds a new ID to the player ID queue, if one has been relinquished.
     *
     * @param newID
     *      The ID to add.
     * @return
     *      True if the ID was added successfully; false otherwise.
     */
    public static boolean addToPlayerIDsQueue(byte newID) {
        if (availablePlayerIDs.contains(newID)) {
            return false;
        }

        availablePlayerIDs.add(newID);
        return true;
    }
}


package server.logic;

import common.Tile;

import java.awt.Point;
import java.io.*;
import java.util.ArrayList;

/**
 * The dungeon map, on which players play the game.
 *
 * @author  Ben Hetherington & University of Bath
 * @version 1.2
 * @release 06/04/2016
 */
public class Map {
	
	private Tile[][] map = null;
	private String mapName = "";
	private byte totalGoldOnMap = 0;

    /**
     * Constructs a new map object, loading the data from the given file.
     *
     * @param mapFile
     *      The map file to load.
     * @throws IOException
     *      Thrown if the file couldn't be read.
     * @throws InvalidMapException
     *      Thrown if the map data is invalid or corrupted.
     */
	public Map(File mapFile) throws IOException, InvalidMapException {
		readMap(mapFile);
	}
	
	/**
	 * Reads a map from a given file.
     * The map should be square, encoded as ASCII art, and begin with the following file header:
	 * name [mapName]
	 * win [totalGold]
	 * 
	 * @param mapFile
     *      A file containing the map to be loaded
	 */
	public void readMap(File mapFile) throws IOException, InvalidMapException {
        BufferedReader reader = new BufferedReader(new FileReader(mapFile));
        map = loadMap(reader);
        reader.close();
	}

    /**
     * Parses the map, using the given input reader.
     * Returns the map, and sets the metadata in the Map object.
     *
     * @param reader
     *      The reader to use for reading data.
     * @return
     *      The loaded map.
     * @throws IOException
     *      Thrown if there is an error reading the file.
     * @throws InvalidMapException
     *      Thrown if the map is not in the correct format.
     */
	private Tile[][] loadMap(BufferedReader reader) throws IOException, InvalidMapException {
		ArrayList<Tile[]> tempMap = new ArrayList<>();
		int width = -1;
		
		String in = reader.readLine();
		if (in.startsWith("name ")) {
			setName(in.substring(5));
		} else {
            throw new InvalidMapException("The map file does not contain a name.");
        }
		
		in = reader.readLine();
		if (in.startsWith("win ")) {
				setWin(in.substring(4));
		} else {
            throw new InvalidMapException("The map file does not contain the amount of gold needed to win.");
        }
		
		in = reader.readLine();
        width = in.trim().length();

        if (width > Byte.MAX_VALUE) {
            throw new InvalidMapException("The map must have a width of " + Byte.MAX_VALUE + " tiles or less.");
        }

		while (in != null) {
			Tile[] row = new Tile[in.length()];

			if (in.length() != width) {
                throw new InvalidMapException("The map has an inconsistent width between rows.");
            }
			
			for (int i = 0; i < in.length(); i++) {
                Tile tile = Tile.valueOf(in.charAt(i));

                if (tile != null) {
                    row[i] = tile;

                } else {
                    throw new InvalidMapException("The map contains an unknown tile: '" + in.charAt(i) + "'.");
                }
			}

			tempMap.add(row);

			in = reader.readLine();
		}

        if (tempMap.size() > Byte.MAX_VALUE) {
            throw new InvalidMapException("The map must have a height of " + Byte.MAX_VALUE + " tiles or less.");
        }

		Tile[][] map = new Tile[tempMap.size()][width];

		for (int i = 0; i < tempMap.size(); i++) {
			map[i] = tempMap.get(i);
		}

		return map;
	}

    /**
     * Sets the amount of gold needed to win the game.
     *
     * @param win
     *      The new win value, as a String.
     * @throws InvalidMapException
     *      Thrown if the string does not contain an integer, or contains a negative integer.
     */
	private void setWin(String win) throws InvalidMapException {
        try {
            totalGoldOnMap = Byte.valueOf(win);

            if (totalGoldOnMap < 0) {
                throw new InvalidMapException("The amount of gold needed to win cannot be negative.");
            } else if (totalGoldOnMap > 99) {
                throw new InvalidMapException("The amount of gold needed to win must be less than 100.");
            }

        } catch (NumberFormatException e) {
            throw new InvalidMapException("The map file contains a non-integer win value.", e);
        }
	}

    /**
     * Sets the name of the map.
     *
     * @param name
     *      The map name.
     */
	private void setName(String name) {
        mapName = name;
	}
	
	/**
	 * Replaces a tile at a given position of the map with a new tile
     *
	 * @param position
     *      The position of the tile to replace
	 * @param tile
     *      The new tile to be placed at the given position
	 * @return
     *      The previous tile, which has now been replaced
	 */
	protected Tile replaceTile(Point position, Tile tile) {
		Tile output = map[position.y][position.x];
		map[position.y][position.x] = tile;
		return output;
	}
	
	protected void printMap() {
        for (int y = 0; y < getMapHeight(); y++) {
            for (int x = 0; x < getMapWidth(); x++) {
                System.out.print(map[y][x]);
            }
            System.out.println();
        }
	}
	
	/**
	 * The method returns the Tile at a given location.
     *
	 * @param position
     *      The position of the tile to examine
	 * @return
     *      The tile at that position
	 */
	public Tile lookAtTile(Point position) {
        if (position.x >= 0 && position.x < getMapWidth() && position.y >= 0 && position.y < getMapHeight()) {
            return map[position.y][position.x];
        } else {
            return Tile.Wall;
        }
	}
	
	/**
	 * Retrieves a map view around a certain location.
	 * This should be used to get the look() around the player location.
     *
	 * @param position
     *      The position to look around; usually the player's position.
	 * @param radius
     *      The radius defining the area which will be returned.
	 *      Without the usage of a lamp the standard value is 5 units.
	 * @return
     *      The tiles to be sent to the client.
	 */
	protected Tile[][] lookWindow(Point position, int radius) {
		Tile[][] reply = new Tile[radius][radius];

		for (int i = 0; i < radius; i++) {
			for (int j = 0; j < radius; j++) {
                Point location = new Point(position.x + j - (radius / 2), position.y + i - (radius / 2));
                reply[j][i] = lookAtTile(location);
			}
		}
		
		return reply;
	}

    /**
     * Returns if the given position contains a tile that will cause a collision, such as a wall.
     *
     * @param position
     *      The position to check.
     * @return
     *      True if there will a collision; false otherwise.
     */
    protected boolean willCollide(Point position) {
        if (position.y < 0 || position.y >= getMapHeight() || position.x < 0 || position.x >= getMapWidth()) {
            return true;
        }

        switch (map[position.y][position.x]) {
            case Wall:
                return true;

            default:
                return false;
        }
    }

    /**
     * @return
     *      The amount of gold needed to win.
     */
	public byte getWin() {
		return totalGoldOnMap;
	}

    /**
     * @return
     *      The name of the map.
     */
	public String getMapName() {
		return mapName;
	}

    /**
     * @return
     *      The width of the map.
     */
	protected int getMapWidth() {
		return map[0].length;
	}

    /**
     * @return
     *      The height of the map.
     */
	protected int getMapHeight() {
		return map.length;
	}

}
package server.logic;

import common.Tile;
import common.network.Events;

import java.awt.Point;

/**
 * Sends events to the client.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class EventSender {

    private GameLogic logic;

    /**
     * Constructs the event sender.
     *
     * @param logic
     *      The game logic to associate with this event sender.
     */
    public EventSender(GameLogic logic) {
        this.logic = logic;
    }

    /**
     * Informs nearby players that a new player has moved into their view.
     *
     * @param movedPlayer
     *      The player that just moved.
     */
    public void sendPlayerMovedEventToNearbyPlayers(Player movedPlayer) {
        for (Player player : logic.players) {
            if (player != movedPlayer && player.shouldKnowAbout(movedPlayer)) {
                Point origin = player.getOriginOfViewForPlayerAlerts();
                Point relativePosition = movedPlayer.getRelativePosition(origin);

                player.sendEvent(Events.PlayerMoved, movedPlayer.getPlayerID(),
                        (byte)relativePosition.x, (byte)relativePosition.y);

                if (!player.knownNearbyPlayers.contains(movedPlayer)) {
                    player.sendEvent(Events.PlayerSpriteChanged, movedPlayer.getPlayerID(),
                            movedPlayer.getCachedCharacter(), movedPlayer.getCachedSprite());
                }

                player.knownNearbyPlayers.add(movedPlayer);

            } else if (player.knownNearbyPlayers.contains(movedPlayer)) {
                player.knownNearbyPlayers.remove(movedPlayer);
                player.sendEvent(Events.PlayerOutOfView, movedPlayer.getPlayerID());
            }
        }
    }

    /**
     * Informs a player moving into a new area, of the players in that area.
     *
     * @param movedPlayer
     *      The player that just moved.
     */
    public void sendPlayerMovedEventToMovedPlayer(Player movedPlayer) {
        for (Player player : logic.players) {
            if (movedPlayer != player && movedPlayer.shouldKnowAbout(player)) {
                // If the moving player is already aware of this player, no need to remind it of them
                if (!movedPlayer.knownNearbyPlayers.contains(player)) {
                    Point origin = movedPlayer.getOriginOfViewForPlayerAlerts();
                    Point relativePosition = player.getRelativePosition(origin);

                    movedPlayer.sendEvent(Events.PlayerMoved, player.getPlayerID(),
                            (byte)relativePosition.x, (byte)relativePosition.y);

                    if (!movedPlayer.knownNearbyPlayers.contains(player)) {
                        movedPlayer.sendEvent(Events.PlayerSpriteChanged, player.getPlayerID(),
                                player.getCachedCharacter(), player.getCachedSprite());
                    }

                    movedPlayer.knownNearbyPlayers.add(player);
                }

            } else if (movedPlayer.knownNearbyPlayers.contains(player)) {
                movedPlayer.knownNearbyPlayers.remove(player);
                movedPlayer.sendEvent(Events.PlayerOutOfView, player.getPlayerID());
            }
        }
    }

    /**
     * Informs nearby players that a player has moved out of view.
     *
     * @param movedPlayer
     *      The player that just moved.
     */
    public void sendPlayerOutOfViewEvent(Player movedPlayer) {
        for (Player player : logic.players) {
            if (player.knownNearbyPlayers.contains(movedPlayer)) {
                player.knownNearbyPlayers.remove(movedPlayer);
                player.sendEvent(Events.PlayerOutOfView, movedPlayer.getPlayerID());
            }
        }
    }

    /**
     * Alerts nearby players that they've changed their sprite.
     *
     * @param modifiedPlayer
     *      The player that changed their sprite.
     * @param characterID
     *      Their new character.
     * @param spriteID
     *      Their new sprite.
     */
    public void sendPlayerSpriteChangedEvent(Player modifiedPlayer, byte characterID, byte spriteID) {
        for (Player player : logic.players) {
            if (player != modifiedPlayer && player.knownNearbyPlayers.contains(modifiedPlayer)) {
                player.sendEvent(Events.PlayerSpriteChanged, modifiedPlayer.getPlayerID(), characterID, spriteID);
            }
        }
    }

    /**
     * Alerts players that a tile in their view has changed.
     *
     * @param position
     *      The position of the changed tile, relative to the entire map.
     * @param newTile
     *      The new tile.
     */
    public void sendTileChangedEvent(Point position, Tile newTile) {
        for (Player player : logic.players) {
            if (player.canSee(position)) {
                Point origin = player.getOriginOfViewForVisibleArea();
                Point relativePosition = new Point(position.x - origin.x, position.y - origin.y);
                player.sendEvent(Events.TileChanged, (byte)relativePosition.x, (byte)relativePosition.y, newTile.byteValue);
            }
        }
    }

    /**
     * Informs a player that their gold counter has changed.
     *
     * @param player
     *      The player that needs informing.
     */
    public void sendGoldChangedEvent(Player player) {
        player.sendEvent(Events.GoldChanged, player.getCollectedGold(), logic.map.getWin());
    }

    /**
     * Sends a player their visible map.
     *
     * @param player
     *      The player to be sent the map.
     */
    public void sendEntireMapUpdate(Player player) {
        int range = player.getVisibleAreaRange();

        Tile[][] mapArray = logic.map.lookWindow(player.getPosition(), range);
        byte[] mapToSend = new byte[range * range];

        for (int i = 0; i < range; i++) {
            for (int j = 0; j < range; j++) {
                mapToSend[(i * range) + j] = mapArray[j][i].byteValue;
            }
        }

        player.sendEvent(Events.EntireMapUpdate, mapToSend);
    }

    /**
     * Updates a row in the player's view.
     *
     * @param relativeY
     *      The y-coordinate of the row, relative to the player's view.
     * @param player
     *      The player to be sent the row.
     */
    public void sendMapRowUpdate(byte relativeY, Player player) {
        Point origin = player.getOriginOfViewForVisibleArea();
        int y = origin.y + relativeY;
        byte[] data = new byte[player.getVisibleAreaRange() + 1];
        data[0] = relativeY;

        for (int i = 0; i < player.getVisibleAreaRange(); i++) {
            data[i + 1] = logic.map.lookAtTile(new Point(origin.x + i, y)).byteValue;
        }

        player.sendEvent(Events.MapRowUpdate, data);
    }

    /**
     * Updates a column in the player's view.
     *
     * @param relativeX
     *      The x-coordinate of the column, relative to the player's view.
     * @param player
     *      The player to be sent the column.
     */
    public void sendMapColumnUpdate(byte relativeX, Player player) {
        Point origin = player.getOriginOfViewForVisibleArea();
        int x = origin.x + relativeX;
        byte[] data = new byte[player.getVisibleAreaRange() + 1];
        data[0] = relativeX;

        for (int i = 0; i < player.getVisibleAreaRange(); i++) {
            data[i + 1] = logic.map.lookAtTile(new Point(x, origin.y + i)).byteValue;
        }

        player.sendEvent(Events.MapColumnUpdate, data);
    }

    /**
     * Informs the player that their view radius has changed.
     *
     * @param player
     *      The player to inform.
     */
    public void sendViewRadiusChangedEvent(Player player) {
        player.sendEvent(Events.ViewRadiusChanged, player.getVisibleAreaRange());
    }

    /**
     * Informs the player that their player alert radius has changed.
     *
     * @param player
     *      The player to inform.
     */
    public void sendPlayerAlertRadiusChangedEvent(Player player) {
        player.sendEvent(Events.PlayerAlertRadiusChanged, player.getPlayerAlertRange());
    }

    /**
     * Informs every player that the game has ended.
     *
     * @param winningPlayer
     *      The player that won the game.
     */
    public void sendGameFinishedEvent(Player winningPlayer) {
        for (Player player : logic.players) {
            player.sendEvent(Events.GameFinished, winningPlayer.getPlayerID());
        }
    }

}

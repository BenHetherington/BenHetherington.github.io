package server.logic;

import common.*;
import common.network.Result;
import server.Server;

import java.awt.Point;
import java.util.*;

/**
 * Encapsulates the main game logic, including the processing all commands.
 *
 * @author  Ben Hetherington & University of Bath
 * @version 1.3
 * @release 06/04/2016
 */
public class GameLogic {

    protected Map map = null;
    protected Set<Player> players = new HashSet<>();

    private Server server;
    private boolean active = false;
    private EventSender eventSender = new EventSender(this);

    public GameLogic(Server server) {
        this.server = server;
    }

    /**
     * @return
     *      The name of the current map.
     */
    public String getMapName() {
        return map.getMapName();
    }

    public void setMap(Map map) {
        this.map = map;
        active = true;
    }

    /**
     * Returns true if the given player has been added to the game, using addPlayer(), and
     * has not yet been removed.
     *
     * @param player
     *      The player to check.
     * @return
     *      True if the given player is currently in the game; false otherwise.
     */
    public boolean isPlayerInGame(Player player) {
        return players.contains(player);
    }

    /**
     * Adds a player to the game, and places them.
     *
     * @param player
     *      The player to add.
     */
    public void addPlayer(Player player) throws TooManyPlayersException {
        players.add(player);
        player.setPosition(initiatePlayer());

        if (player.getPosition() != null) {
            eventSender.sendViewRadiusChangedEvent(player);
            eventSender.sendPlayerAlertRadiusChangedEvent(player);

            eventSender.sendPlayerMovedEventToMovedPlayer(player);
            eventSender.sendPlayerMovedEventToNearbyPlayers(player);

            eventSender.sendEntireMapUpdate(player);
            eventSender.sendGoldChangedEvent(player);

        } else {
            // There is no space for the new player
            throw new TooManyPlayersException();
        }
    }

    /**
     * Removes a player from the game. Does not relinquish the gold they've already collected.
     *
     * @param player
     *      The player to remove.
     */
    public void removePlayer(Player player) {
        players.remove(player);
        eventSender.sendPlayerOutOfViewEvent(player);
        Player.addToPlayerIDsQueue(player.getPlayerID());
    }

    /**
     * Moves a player in the given direction, checking for collisions in the process.
     *
     * @param player
     *      The player that issued the MOVE command.
     * @param direction
     *      The direction to move in
     * @return
     *      'Success' if the move succeeded; 'Fail' otherwise.
     */
    public synchronized Result move(Player player, Direction direction) {
        Point newPosition = new Point(player.getPosition());

        switch (direction) {
            case Up:
                newPosition.y -= 1;
                break;

            case Right:
                newPosition.x += 1;
                break;

            case Down:
                newPosition.y += 1;
                break;

            case Left:
                newPosition.x -= 1;
                break;

            default:
                return Result.Fail;
        }
        
        if (!willCollide(newPosition)) {
            player.setEventsEnabled(false);
            player.setPosition(newPosition);

            switch (direction) {
                case Up:
                    eventSender.sendMapRowUpdate((byte)0, player);
                    break;

                case Right:
                    eventSender.sendMapColumnUpdate((byte)(player.getVisibleAreaRange() - 1), player);
                    break;

                case Down:
                    eventSender.sendMapRowUpdate((byte)(player.getVisibleAreaRange() - 1), player);
                    break;

                case Left:
                    eventSender.sendMapColumnUpdate((byte)0, player);
                    break;
            }
            
            if (checkWin(player)) {
                eventSender.sendGameFinishedEvent(player);
                quitGame();
            }

            eventSender.sendPlayerMovedEventToMovedPlayer(player);
            eventSender.sendPlayerMovedEventToNearbyPlayers(player);

            return Result.Success;

        } else {
            return Result.Fail;
        }
    }

    /**
     * Picks up gold if the player is standing on a tile with gold on it.
     * That tile becomes a regular space afterwards.
     *
     * @param player
     *      The player that issued the PICKUP command.
     * @return
     *      'Success' if the gold was picked up; 'Fail' if there is no gold to pick up.
     */
    public Result pickup(Player player) {
        if (map.lookAtTile(player.getPosition()) == Tile.Gold) {
            player.collectGold(1);
            map.replaceTile(player.getPosition(), Tile.Empty);

            eventSender.sendGoldChangedEvent(player);
            eventSender.sendTileChangedEvent(player.getPosition(), Tile.Empty);
            return Result.Success;

        } else {
            return Result.Fail;
        }
    }

    /**
     * Updates a player's sprite.
     * This is both stored in a cache on the server, and is sent to all nearby players.
     *
     * @param player
     *      The player whose sprite has changed.
     * @param characterID
     *      Their new character.
     * @param spriteID
     *      Their new sprite.
     * @return
     *      This will always return 'Success'.
     */
    public Result changeSprite(Player player, byte characterID, byte spriteID) {
        player.setCachedCharacter(characterID);
        player.setCachedSprite(spriteID);
        eventSender.sendPlayerSpriteChangedEvent(player, characterID, spriteID);
        return Result.Success;
    }

    /*
     * Prints the whole map directly to Standard out.
     */
    public void printMap() {
        map.printMap();
    }

    /**
     * Gets the positions of every player in the game.
     *
     * @return
     *      A set containing the positions of every player in the game.
     */
    private synchronized Set<Point> getAllPlayerPositions() {
        Set<Point> returnValue = new HashSet<>();

        for (Player player : players) {
            returnValue.add(player.getPosition());
        }

        return returnValue;
    }

    /**
     * Checks for a collision at the given position with an obstacle on the map, or another player.
     *
     * @param position
     *      The position to check.
     * @return
     *      True if there would be a collision at this position; false otherwise.
     */
    private boolean willCollide(Point position) {
        if (map.willCollide(position)) {
            return true;

        } else {
            for (Point playerPosition : getAllPlayerPositions()) {
                if (position.equals(playerPosition)) {
                    return true;
                }
            }

            return false;
        }
    }

    /**
     * Finds a random position for the player in the map.
     *
     * @return
     *      Returns the position that the player was placed, or null if the player can't be placed.
     */
    private Point initiatePlayer() {
        Random rand = new Random();

        ArrayList<Point> possibleStartPositions = new ArrayList<>();

        for (int y = 0; y < map.getMapHeight(); y++) {
            for (int x = 0; x < map.getMapWidth(); x++) {
                Point point = new Point(x, y);

                if (!willCollide(point)) {
                    possibleStartPositions.add(point);
                }
            }
        }

        if (possibleStartPositions.size() > 0) {
            return possibleStartPositions.get(rand.nextInt(possibleStartPositions.size()));
        } else {
            return null;
        }
    }

    /**
     * Checks if the player collected all the needed gold, and is on the exit tile.
     *
     * @param player
     *      The player to check.
     * @return
     *      True if all the win conditions have been met; false otherwise.
     */
    private boolean checkWin(Player player) {
        if (player.getCollectedGold() >= map.getWin() && map.lookAtTile(player.getPosition()) == Tile.Exit) {
            server.logMessage("Player " + player.getPlayerID() + " has escaped the dungeon!");
            return true;

        } else {
            return false;
        }
    }

    /**
     * Spawns more gold onto the map, in a random position.
     *
     * @param amount
     *      The amount of gold to spawn.
     * @return
     *      True if the gold was spawned successfully; false if there isn't space.
     */
    private boolean spawnGold(int amount) {
        if (amount <= 0) {
            return false;
        }

        Random rand = new Random();

        ArrayList<Point> possibleSpawnPositions = new ArrayList<>();

        for (int y = 0; y < map.getMapHeight(); y++) {
            for (int x = 0; x < map.getMapWidth(); x++) {
                Point point = new Point(x, y);

                if (map.lookAtTile(point) == Tile.Empty) {
                    possibleSpawnPositions.add(point);
                }
            }
        }

        if (possibleSpawnPositions.size() >= amount) {
            for (int i = 0; i < amount; i++) {
                int index = rand.nextInt(possibleSpawnPositions.size());
                Point position = possibleSpawnPositions.get(index);
                possibleSpawnPositions.remove(index);

                map.replaceTile(position, Tile.Gold);
            }
            return true;

        } else {
            return false;
        }
    }

    /**
     * Stops the game loop.
     */
    public void quitGame() {
        active = false;
    }

    /**
     * @return
     *      True if the game loop should continue; false otherwise.
     */
    public boolean isGameRunning() {
        return active;
    }

}

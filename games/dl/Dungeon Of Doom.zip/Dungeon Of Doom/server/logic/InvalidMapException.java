package server.logic;

/**
 * An exception that's thrown when trying to load an invalid map.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 09/03/2016
 * @see     Exception
 */
public class InvalidMapException extends Exception {

    /**
     * {@inheritDoc}
     */
    InvalidMapException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    InvalidMapException(String message, Exception cause) {
        super(message, cause);
    }

}

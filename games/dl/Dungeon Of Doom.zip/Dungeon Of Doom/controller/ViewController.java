package controller;

import client.*;
import client.bot.Bot;
import common.*;
import common.network.Result;
import common.sound.*;
import server.Server;
import server.logic.*;
import view.controls.ControlPanel;
import view.controls.MoveButton;
import view.map.*;
import view.player.*;
import view.status.*;
import view.window.MainWindow;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * The view controller for Dungeon of Doom.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class ViewController {

    final static public int FADE_TIME = 250;
    final static public int MOVE_TIME = 250;

    private MainWindow mainWindow = new MainWindow();
    private SoundEngine soundEngine = new SoundEngine();
    private ControlListener controlListener = new ControlListener(new ControlHandler(this));

    private boolean isInGame = false;
    private Direction movementDirection = null;
    private Direction lastMovementDirection = null;

    private String serverAddress;
    private int serverPort;

    private Timer messageTimeoutTimer;

    private Server server;
    private ClientLogic clientLogic;
    private Bot bot;

    /**
     * Constructs a view controller. Displays the UI in the process.
     */
    public ViewController() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                mainWindow.setVisible(true);
                setUpControlPanelListeners();
                setUpTitleScreenButtons();
                setUpMenuBar();

                goToMainMenu(false);
            }
        });
    }

    /**
     * Sets up the listeners for the control panel.
     */
    private void setUpControlPanelListeners() {
        mainWindow.addKeyListener(controlListener);

        for (MoveButton button : getControlPanel().getMovePanel().getButtons().values()) {
            button.addMouseListener(controlListener);
        }
        getControlPanel().getPickupButton().addMouseListener(controlListener);

        getControlPanel().getQuitButton().addActionListener(controlListener);
    }

    /**
     * Sets up the actions for the buttons on the title screen.
     */
    private void setUpTitleScreenButtons() {
        mainWindow.getTitleScreen().getHostButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setUpServer();
            }
        });

        mainWindow.getTitleScreen().getJoinButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setUpGame();
            }
        });
    }

    /**
     * Sets up the actions for the menu bar.
     */
    private void setUpMenuBar() {
        mainWindow.getMyMenuBar().getShowControlsItem().setState(GamePreferences.isControlsShown());

        mainWindow.getMyMenuBar().getShowControlsItem().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                boolean showControls = mainWindow.getMyMenuBar().getShowControlsItem().getState();
                GamePreferences.setControlsShown(showControls);
                mainWindow.displayControls(showControls);
            }
        });

        mainWindow.getMyMenuBar().getEnableBotItem().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (bot != null && bot.isGameRunning()) {
                    bot.quit();
                }

                if (mainWindow.getMyMenuBar().getEnableBotItem().getState()) {
                    // Then we need to add the bot
                    bot = new Bot();
                    try {
                        bot.connect(serverAddress, serverPort);
                        new Thread(new Runnable() {
                            public void run() {
                                bot.run();
                            }
                        }, "Bot Thread").start();

                    } catch (IOException e1) {
                        DialogDisplayer.showErrorMessage("Dungeon Of Doom", "Couldn't add the bot to the game.", e1);
                    }

                }
            }
        });
    }

    /**
     * Run when the user chooses to host a game. Sets up a server.
     *
     * @return
     *      True if the server was set up successfully; false otherwise.
     */
    public boolean setUpServer() {
        File file = DialogDisplayer.askForMapLocation(mainWindow);
        if (file == null) {
            return false;
        }

        Map map;
        try {
            map = new Map(file);

        } catch (IOException | InvalidMapException e) {
            DialogDisplayer.showErrorMessage("Error Reading Map", "The map file couldn't be read.", e);
            return false;
        }

        Integer port = DialogDisplayer.askForPortNumber();
        if (port == null) {
            return false;
        }

        try {
            server = new Server(port, map);

        } catch (IOException e) {
            DialogDisplayer.showErrorMessage("Error Starting Server", "The server couldn't be started.", e);
            return false;
        }

        clientLogic = new GUIClientLogic(this);
        try {
            clientLogic.connect("localhost", port);

            serverAddress = "localhost";
            serverPort = port;
            goToGame();

        } catch (IOException e) {
            DialogDisplayer.showErrorMessage("Error Connecting To Server", "Couldn't join the game.", e);
            return false;
        }

        return true;
    }

    /**
     * Run when the user chooses to join a game. Sets up a connection to another server.
     *
     * @return
     *      True if the connection was successful; false otherwise.
     */
    public boolean setUpGame() {
        Object[] serverInfo = DialogDisplayer.askForServerInfo();
        if (serverInfo == null) {
            return false;
        }

        clientLogic = new GUIClientLogic(this);
        try {
            clientLogic.connect((String)serverInfo[0], (int)serverInfo[1]);
        } catch (IOException e) {
            DialogDisplayer.showErrorMessage("Error Connecting To Server", "Couldn't connect to the server.", e);
            return false;
        }

        serverAddress = (String)serverInfo[0];
        serverPort = (int)serverInfo[1];
        goToGame();
        return true;
    }

    /**
     * Stops the client and server.
     */
    private void resetClientAndServer() {
        if (clientLogic != null && clientLogic.isGameRunning()) {
            clientLogic.quit();
        }

        if (bot != null && bot.isGameRunning()) {
            bot.quit();
        }

        if (server != null) {
            try {
                server.getLogic().quitGame();
                server.stop();
            } catch (IOException e) {
                // Not too much we can do about this
            }
        }

        clientLogic = null;
        bot = null;
        server = null;
    }

    /**
     * Begins the transition to the main menu.
     * Begins a fade animation if necessary.
     */
    public void goToMainMenu() {
        resetClientAndServer();

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                if (isInGame) {
                    mainWindow.getMyMenuBar().getEnableBotItem().setEnabled(false);
                    mainWindow.getMyMenuBar().getEnableBotItem().setState(false);

                    mainWindow.getFadeRect().setCallback(new Runnable() {
                        public void run() {
                            goToMainMenu(true);
                        }
                    });
                    mainWindow.getFadeRect().fadeIn(FADE_TIME);

                } else {
                    goToMainMenu(false);
                }
            }
        });
    }

    /**
     * Moves to the main menu, after the fade.
     *
     * @param withFade
     *      True if the main menu should be faded in.
     */
    private void goToMainMenu(boolean withFade) {
        mainWindow.getFadeRect().setCallback(null);
        isInGame = false;

        mainWindow.getMyMenuBar().getEnableBotItem().setEnabled(false);
        mainWindow.getMyMenuBar().getEnableBotItem().setState(false);

        getStatusView().setImage(null);
        Set<Byte> playerKeys = new HashSet<>(getGameViewport().getPlayerViewKeys());
        for (byte key : playerKeys) {
            getGameViewport().removePlayerView(key);
        }

        mainWindow.getTitleScreen().setEnabled(true);
        mainWindow.getControlPanel().setEnabled(false);
        mainWindow.setUpMainMenuUI();

        resetClientAndServer();

        if (withFade) {
            mainWindow.getFadeRect().fadeOut(FADE_TIME);
        }
    }

    /**
     * Begins the transition to the game screen.
     * Begins a fade animation if necessary.
     */
    public void goToGame() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                if (!isInGame) {
                    mainWindow.getFadeRect().setCallback(new Runnable() {
                        public void run() {
                            goToGame(true);
                        }
                    });
                    mainWindow.getTitleScreen().setEnabled(false);
                    mainWindow.getFadeRect().fadeIn(FADE_TIME);

                } else {
                    goToGame(false);
                }
            }
        });
    }

    /**
     * Moves to the game screen, after the fade.
     *
     * @param withFade
     *      True if the game screen should be faded in.
     */
    private void goToGame(boolean withFade) {
        mainWindow.getFadeRect().setCallback(null);
        isInGame = true;

        mainWindow.setUpGameUI();
        getControlPanel().setEnabled(true);
        getMap().scroll(new Point(TileView.TILE_SIZE, TileView.TILE_SIZE));

        Random rand = new Random();
        Characters character = rand.nextBoolean() ? Characters.Ethan : Characters.Kris;

        PlayerView me = mainWindow.getGameContentPanel().getGameViewport().addPlayerView(clientLogic.getPlayerID(), character);
        me.setLocation(2 * 16 * GamePreferences.getScale(), 2 * 16 * GamePreferences.getScale());
        clientLogic.changeSprite(me.getCharacter(), me.getSprite());

        mainWindow.getMyMenuBar().getEnableBotItem().setEnabled(true);

        if (withFade) {
            mainWindow.getFadeRect().fadeOut(FADE_TIME);
        }
    }

    /**
     * Sets up a timeout for a message in the status view.
     *
     * @param delay
     *      The desired timeout delay.
     */
    public void startMessageTimeout(int delay) {
        if (messageTimeoutTimer != null) {
            messageTimeoutTimer.stop();
        }

        messageTimeoutTimer = new Timer(delay, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                getStatusView().setImage(null);
            }
        });
        messageTimeoutTimer.setRepeats(false);
        messageTimeoutTimer.start();
    }

    /**
     * Gets the current direction, and moves if necessary.
     * Called after a move button is pressed, if not currently moving, or called after a move animation has finished.
     */
    protected void moveCallback() {
        if (!clientLogic.isGameRunning()) {
            return;
        }

        final PlayerView player = getGameViewport().getPlayerView(clientLogic.getPlayerID());

        Runnable task = new Runnable() {
            public synchronized void run() {
                getMap().scroll(new Point(TileView.TILE_SIZE, TileView.TILE_SIZE));

                final Direction movementDirection = ViewController.this.movementDirection;
                if (movementDirection != null) {
                    getMap().setAllowUpdates(false);

                    if (clientLogic.move(movementDirection) == Result.Fail) {
                        getMap().setAllowUpdates(true);
                        Utilities.invokeOnSwingThreadAndWait(new Runnable() {
                            public void run() {
                                player.setSprite(Sprites.getSprite(movementDirection, false));
                            }
                        });
                        clientLogic.changeSprite(player.getCharacter(), player.getSprite());

                        soundEngine.playSound(SoundEffect.CantWalkIntoWalls);
                        return;
                    }

                    synchronized (getMap()) {
                        shiftMapTiles(movementDirection);
                        moveMap(movementDirection);
                        getMap().setAllowUpdates(true);
                    }

                    if (movementDirection != lastMovementDirection) {
                        Utilities.invokeOnSwingThreadAndWait(new Runnable() {
                            public void run() {
                                player.setSprite(Sprites.getSprite(movementDirection, true));
                            }
                        });
                        clientLogic.changeSprite(player.getCharacter(), player.getSprite());
                    }

                } else {

                    if (lastMovementDirection != null) {
                        Utilities.invokeOnSwingThreadAndWait(new Runnable() {
                            public void run() {
                                player.setSprite(Sprites.getSprite(lastMovementDirection, false));
                            }
                        });
                        clientLogic.changeSprite(player.getCharacter(), player.getSprite());
                    }
                }

                lastMovementDirection = movementDirection;
            }
        };

        new Thread(task, "Move Callback Networking").start();
    }

    /**
     * Shifts the map's tiles, for movement in the given direction.
     *
     * @param direction
     *      The direction to move in.
     */
    private synchronized void shiftMapTiles(Direction direction) {
        switch (direction) {
            case Up:
                // If we walked up, we need to shift the map downwards
                for (int i = clientLogic.getViewRadius(); i >= 0; i--) {
                    for (int j = 0; j < clientLogic.getViewRadius() + 2; j++) {
                        Tile tile = getMap().getTile(j, i);
                        getMap().setTile(j, i + 1, tile, false);
                    }
                }
                break;

            case Down:
                // If we walked down, we need to shift the map upwards
                for (int i = 1; i < clientLogic.getViewRadius() + 2; i++) {
                    for (int j = 0; j < clientLogic.getViewRadius() + 2; j++) {
                        Tile tile = getMap().getTile(j, i);
                        getMap().setTile(j, i - 1, tile, false);
                    }
                }
                break;

            case Left:
                // If we walked left, we need to shift the map to the right
                for (int i = 0; i < clientLogic.getViewRadius() + 2; i++) {
                    for (int j = clientLogic.getViewRadius(); j >= 0; j--) {
                        Tile tile = getMap().getTile(j, i);
                        getMap().setTile(j + 1, i, tile, false);
                    }
                }
                break;

            case Right:
                // If we walked right, we need to shift the map to the left
                for (int i = 0; i < clientLogic.getViewRadius() + 2; i++) {
                    for (int j = 1; j < clientLogic.getViewRadius() + 2; j++) {
                        Tile tile = getMap().getTile(j, i);
                        getMap().setTile(j - 1, i, tile, false);
                    }
                }
                break;
        }

        moveMap(direction, true);
    }

    /**
     * Animates the map movement, for movement in the given direction.
     *
     * @param direction
     *      The direction to move the map.
     */
    public void moveMap(Direction direction) {
        moveMap(direction, false);
    }

    /**
     * Moves the map, animating if necessary.
     *
     * @param direction
     *      The movement direction.
     *
     * @param shiftOnly
     *      If true, the map is not animated, and the directions are reversed.
     *      Should only be true if used by shiftMapTiles().
     */
    public void moveMap(Direction direction, boolean shiftOnly) {
        // For moving the map along with this client's player
        int dx = 0;
        int dy = 0;

        switch (direction) {
            case Up:
                dy = -TileView.TILE_SIZE;
                break;

            case Down:
                dy = TileView.TILE_SIZE;
                break;

            case Left:
                dx = -TileView.TILE_SIZE;
                break;

            case Right:
                dx = TileView.TILE_SIZE;
                break;
        }

        if (!shiftOnly) {
            getMap().animateScroll(dx, dy, MOVE_TIME);

            GameViewport gameViewport = mainWindow.getGameContentPanel().getGameViewport();

            for (byte key : gameViewport.getPlayerViewKeys()) {
                if (key != clientLogic.getPlayerID()) {
                    gameViewport.getPlayerView(key).animateMovementWithMap(-dx, -dy, MOVE_TIME);
                }
            }

        } else {
            getMap().scroll(new Point(getMap().getPoint().x - dx, getMap().getPoint().y - dy));
        }
    }

    /**
     * Handles a communication error.
     *
     * @param cause
     *      The reason for the communication error.
     */
    public void handleCommunicationError(Exception cause) {
        DialogDisplayer.showErrorMessage("Dungeon Of Doom", "A communication error has occured.", cause);
        goToMainMenu();
    }

    /**
     * @return
     *      The gold display.
     */
    public GoldDisplay getGoldDisplay() {
        return mainWindow.getGameContentPanel().getStatusView().getGoldDisplay();
    }

    /**
     * @return
     *      The map.
     */
    public ScrollingMap getMap() {
        return mainWindow.getGameContentPanel().getGameViewport().getMap();
    }

    /**
     * @return
     *      The game viewport.
     */
    public GameViewport getGameViewport() {
        return mainWindow.getGameContentPanel().getGameViewport();
    }

    /**
     * @return
     *      The status view.
     */
    public StatusView getStatusView() {
        return mainWindow.getGameContentPanel().getStatusView();
    }

    /**
     * @return
     *      The control panel.
     */
    public ControlPanel getControlPanel() {
        return mainWindow.getControlPanel();
    }

    /**
     * @return
     *      The sound engine.
     */
    public SoundEngine getSoundEngine() {
        return soundEngine;
    }

    /**
     * @return
     *      The current movement direction.
     */
    public Direction getMovementDirection() {
        return movementDirection;
    }

    /**
     * Sets the curremt movement direction.
     *
     * @param movementDirection
     *      The new movement direction.
     */
    public void setMovementDirection(Direction movementDirection) {
        this.movementDirection = movementDirection;
    }

    /**
     * @return
     *      The client logic currently in use.
     */
    public ClientLogic getClientLogic() {
        return clientLogic;
    }
}
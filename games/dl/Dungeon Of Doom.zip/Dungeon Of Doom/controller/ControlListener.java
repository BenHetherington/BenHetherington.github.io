package controller;

import common.Direction;
import view.controls.*;

import java.awt.event.*;
import java.util.*;

/**
 * Listens to raw mouse and keyboard events, interprets them, and passes them to the ControlHandler.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class ControlListener implements KeyListener, MouseListener, ActionListener {

    private ControlHandlerInterface callback;
    private Map<Direction, Boolean> mouseButtonsPressed = new HashMap<>();
    private Map<Direction, Boolean> keysPressed = new HashMap<>();

    private long lastKeyReleased = 0;
    private Timer keyReleasedTimer;

    /**
     * Constructs a control listner.
     *
     * @param callback
     *      The control handler to be called when an event needs handling.
     */
    public ControlListener(ControlHandlerInterface callback) {
        this.callback = callback;

        for (Direction direction : Direction.values()) {
            mouseButtonsPressed.put(direction, false);
            keysPressed.put(direction, false);
        }
    }

    /**
     * Gets the current direction, from either the on-screen buttons, or the keyboard.
     * Favours the on-screen buttons, if both a keyboard direction and that are being pressed simultaneously.
     * If multiple directions on the keyboard are being pressed simultaneously, one will be chosen with no particular preference.
     * If no keys are being pressed, null will be returned.
     *
     * @return
     *      The currently held direction.
     */
    private Direction getCurrentDirection() {
        for (Direction direction : mouseButtonsPressed.keySet()) {
            if (mouseButtonsPressed.get(direction)) {
                return direction;
            }
        }

        for (Direction direction : keysPressed.keySet()) {
            if (keysPressed.get(direction)) {
                return direction;
            }
        }

        return null;
    }

    /**
     * Handles a key pressed event.
     * @param e
     *      The event to handle.
     */
    public void keyPressed(KeyEvent e) {
        if (e.getWhen() - lastKeyReleased <= 1) {
            keyReleasedTimer.cancel();
        }

        handleKeyEvent(e, true);
    }

    /**
     * Handles a key released event.
     * @param e
     *      The event to handle.
     */
    public void keyReleased(final KeyEvent e) {
        // Unfortunately, since Linux sends keyReleased events when holding down the key,
        // I have to do a bit of hackery to get around it
        lastKeyReleased = e.getWhen();

        keyReleasedTimer = new Timer("Key Released Timer");
        keyReleasedTimer.schedule(new TimerTask() {
            public void run() {
                handleKeyEvent(e, false);
            }
        }, 3);
    }

    /**
     * Handles a mouse pressed event.
     * @param e
     *      The event to handle.
     */
    public void mousePressed(MouseEvent e) {
        handleMouseEvent(e, true);
    }

    /**
     * Handles a mouse released event.
     * @param e
     *      The event to handle.
     */
    public void mouseReleased(MouseEvent e) {
        handleMouseEvent(e, false);
    }

    /**
     * Handles either kind of key event.
     * @param e
     *      The event to handle.
     * @param isPressed
     *      True if the key was pressed; false if the key was released.
     */
    private void handleKeyEvent(KeyEvent e, boolean isPressed) {
        Direction direction;

        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                direction = Direction.Up;
                break;

            case KeyEvent.VK_DOWN:
                direction = Direction.Down;
                break;

            case KeyEvent.VK_LEFT:
                direction = Direction.Left;
                break;

            case KeyEvent.VK_RIGHT:
                direction = Direction.Right;
                break;

            case KeyEvent.VK_SPACE:
                if (isPressed) {
                    callback.pickupPerformed();
                }
                return;

            default:
                return;
        }

        keysPressed.put(direction, isPressed);
        callback.directionChanged(getCurrentDirection());
    }

    /**
     * Handles either kind of mouse event.
     *
     * @param e
     *      The event to handle.
     * @param isPressed
     *      True if the mouse button is pressed; false if it's released.
     */
    private void handleMouseEvent(MouseEvent e, boolean isPressed) {
        if (e.getButton() == MouseEvent.BUTTON1) {
            if (e.getSource() instanceof MoveButton) {
                MoveButton button = (MoveButton) e.getSource();

                if (button.isEnabled()) {
                    Direction direction = button.getDirection();
                    mouseButtonsPressed.put(direction, isPressed);
                    callback.directionChanged(getCurrentDirection());
                }
            } else if (e.getSource() instanceof PickupButton) {
                PickupButton button = (PickupButton) e.getSource();

                if (button.isEnabled() && isPressed) {
                    callback.pickupPerformed();
                }
            }
        }
    }

    /**
     * Handles the quit button being pressed.
     *
     * @param e
     *      The event to handle.
     */
    public void actionPerformed(ActionEvent e) {
        callback.quitPressed();
    }

    // Unused events
    public void keyTyped(KeyEvent e) { }
    public void mouseEntered(MouseEvent e) { }
    public void mouseClicked(MouseEvent e) { }
    public void mouseExited(MouseEvent e) { }

}

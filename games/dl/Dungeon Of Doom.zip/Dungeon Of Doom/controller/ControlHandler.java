package controller;

import common.Direction;
import common.Utilities;
import common.network.Result;
import common.sound.SoundEffect;

import java.awt.*;

/**
 * Handles events from the controls.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class ControlHandler implements ControlHandlerInterface {

    private ViewController viewController;

    /**
     * Constructs a new control handler.
     *
     * @param viewController
     *      The view controller to associate with this control handler.
     */
    ControlHandler(ViewController viewController) {
        this.viewController = viewController;
    }

    /**
     * Handles a change in movement direction.
     *
     * @param newDirection
     *      The new direction to move in.
     */
    public void directionChanged(Direction newDirection) {
        if (!viewController.getClientLogic().isGameRunning()) {
            return;
        }

        if (viewController.getControlPanel().getMovePanel().isEnabled()) {
            if (viewController.getMovementDirection() != newDirection) {
                viewController.setMovementDirection(newDirection);

                if (!viewController.getMap().isAnimating()) {
                    viewController.getMap().setAnimationCallback(new Runnable() {
                        public void run() {
                            viewController.moveCallback();
                        }
                    });

                    viewController.moveCallback();
                }
            }

        } else {
            Toolkit.getDefaultToolkit().beep();
        }
    }

    /**
     * Handles a pickup event.
     */
    public void pickupPerformed() {
        if (!viewController.getClientLogic().isGameRunning()) {
            return;
        }

        Runnable task = new Runnable() {
            public synchronized void run() {
                if (viewController.getClientLogic().pickup() == Result.Success) {
                    viewController.getSoundEngine().playSound(SoundEffect.Pickup);

                } else {
                    Utilities.invokeOnSwingThreadAndWait(new Runnable() {
                        public void run() {
                            viewController.getStatusView().setText("NOTHING TO\nPICK UP!");
                        }
                    });

                    viewController.startMessageTimeout(1500);
                    viewController.getSoundEngine().playSound(SoundEffect.CantPickup);
                }
            }
        };

        new Thread(task, "Pickup Networking").start();
    }

    /**
     * Handles the quit button.
     */
    public void quitPressed() {
        Boolean result = DialogDisplayer.promptToLeaveGame();

        if (result != null) {
            if (!result) {
                // Leave
                viewController.goToMainMenu();

            } else {
                // Leave and quit
                System.exit(0);
            }
        }
    }

}

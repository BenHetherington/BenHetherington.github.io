package controller;

import common.Direction;

/**
 * An interface for a generic control handler, to be attached to the control listener.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public interface ControlHandlerInterface {

    void directionChanged(Direction newDirection);
    void pickupPerformed();
    void quitPressed();

}

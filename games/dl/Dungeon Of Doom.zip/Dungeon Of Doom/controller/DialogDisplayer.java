package controller;

import common.GamePreferences;
import common.Utilities;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FilenameFilter;

/**
 * Displays modal dialog boxes.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class DialogDisplayer {

    private DialogDisplayer() {
        // To ensure that DialogDisplayers can't be constructed.
    }

    /**
     * Ask for the information of a server to connect to.
     *
     * @return
     *      Returns an array with the address (a String) at index 0, and the port (an Integer) at index 1.
     */
    public static Object[] askForServerInfo() {
        String title = "Connect To Server";
        String message = "Enter the IP Address and port of\nthe server that you'd like to connect to.";
        String initialServer = GamePreferences.getInitialServer();

        String errorMessage = "The given information was invalid.\n" + message;

        for (;;) {
            String result = (String) JOptionPane.showInputDialog(null, message, title, JOptionPane.PLAIN_MESSAGE, null, null, initialServer);

            if (result == null) {
                // Cancel button pressed
                return null;

            } else if (result.split(":").length == 2) {
                String[] parts = result.split(":");

                try {
                    String address = parts[0];
                    int port = Integer.valueOf(parts[1]);

                    if (port > 65335 || port < 0) {
                        throw new NumberFormatException("The port must be a 16-bit number.");
                    }

                    GamePreferences.setInitialServer(result);
                    return new Object[]{address, port};

                } catch (NumberFormatException e) {
                    // Invalid port number
                    message = errorMessage;
                    initialServer = result;
                }

            } else {
                // Invalid server information
                initialServer = result;
                message = errorMessage;
            }
        }
    }

    /**
     * Asks for the map file to use.
     *
     * @param parent
     *      The parent window.
     * @return
     *      The selected file.
     */
    public static File askForMapLocation(JFrame parent) {
        FileDialog fileDialog = new FileDialog(parent, "Choose Map");

        if (new File(Utilities.getWorkingDirectory() + "/maps/").exists()) {
            fileDialog.setDirectory(Utilities.getWorkingDirectory() + "/maps/");
        }
        fileDialog.setFilenameFilter(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.toLowerCase().endsWith(".dod");
            }
        });

        fileDialog.setVisible(true);

        if (fileDialog.getFiles().length > 0) {
            return fileDialog.getFiles()[0];
        } else {
            return null;
        }
    }

    /**
     * Asks for the port number to use when starting a server.
     *
     * @return
     *      The entered port number.
     */
    public static Integer askForPortNumber() {
        String title = "Start Server";
        String message = "Enter the port you'd like to use.";
        String initialPort = GamePreferences.getInitialPort();

        String errorMessage = "The given port was invalid.\n" + message;

        for (;;) {
            String result = (String)JOptionPane.showInputDialog(null, message, title, JOptionPane.PLAIN_MESSAGE, null, null, initialPort);

            if (result != null) {
                try {
                    int port = Integer.valueOf(result);

                    if (port > 65335 || port < 0) {
                        throw new NumberFormatException("The port must be a 16-bit number.");
                    }

                    GamePreferences.setInitialPort(result);
                    return port;

                } catch (NumberFormatException e) {
                    // Invalid port number
                    message = errorMessage;
                    initialPort = result;
                }

            } else {
                // Cancel button pressed
                return null;
            }
        }
    }

    /**
     * Displays an error message.
     *
     * @param title
     *      The title of the dialog.
     * @param message
     *      The message of the dialog.
     */
    public static void showErrorMessage(String title, String message) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Displays an error message, appending the exception's localised message, if it has one.
     *
     * @param title
     *      The title of the dialog.
     * @param message
     *      The message of the dialog.
     * @param exception
     *      The exception that caused the error.
     */
    public static void showErrorMessage(String title, String message, Exception exception) {
        if (exception.getLocalizedMessage() != null) {
            message += '\n' + exception.getLocalizedMessage();
        }
        showErrorMessage(title, message);
    }

    /**
     * Asks the user if they want to leave the game.
     *
     * @return
     *      False if they want to leave; true if they want to quit DoD; null if they want to cancel.
     */
    public static Boolean promptToLeaveGame() {
        String title = "Dungeon Of Doom";
        String description = "Are you sure that you want to leave this game?\n"
            + "If you are hosting the game, this will also\ndisconnect all other players.\n"
            + "('Leave & Quit' will also quit Dungeon of Doom)";
        String[] options = new String[]{"Leave", "Leave & Quit", "Cancel"};

        int result = JOptionPane.showOptionDialog(null, description, title, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        switch (result) {
            case 0:
                // Leave
                return false;

            case 1:
                // Leave & Quit
                return true;

            default:
                // Cancel, or closed dialog
                return null;
        }
    }

}

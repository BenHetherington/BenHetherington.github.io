package view.window;

import javax.swing.*;

public class MenuBar extends JMenuBar {

    private JCheckBoxMenuItem showControlsItem = new JCheckBoxMenuItem("Show controls", true);
    private JCheckBoxMenuItem enableBotItem = new JCheckBoxMenuItem("Enable Bot");

    public MenuBar() {
        JMenu viewMenu = new JMenu("View");
        viewMenu.add(showControlsItem);
        add(viewMenu);

        JMenu botMenu = new JMenu("Bot");
        botMenu.add(enableBotItem);
        add(botMenu);
    }

    public JCheckBoxMenuItem getShowControlsItem() {
        return showControlsItem;
    }

    public JCheckBoxMenuItem getEnableBotItem() {
        return enableBotItem;
    }
}

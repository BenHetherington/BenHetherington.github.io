package view.window;

import common.GamePreferences;
import common.image.ImageUtilities;
import view.foundation.ImageButton;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * The game's title screen.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class TitleScreen extends JLayeredPane {

    private ImageButton hostButton;
    private ImageButton joinButton;

    /**
     * Constructs a new title screen.
     */
    public TitleScreen() {
        Dimension size = new Dimension(80 * GamePreferences.getScale(), 104 * GamePreferences.getScale()); // TODO: Make this dynamic
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        setUpBackground();
        setUpButtons();
    }

    /**
     * Sets up the background graphic.
     */
    private void setUpBackground() {
        BufferedImage backgroundImage = ImageUtilities.loadImage(new File("./graphics/title-screen/background.png"));
        JLabel background = new JLabel(new ImageIcon(ImageUtilities.resizeImage(backgroundImage, GamePreferences.getScale())));
        background.setLocation(0, 0);
        background.setSize(getPreferredSize());
        add(background, DEFAULT_LAYER);
    }

    /**
     * Sets up the 'Host Game' and 'Join Game' buttons.
     */
    private void setUpButtons() {
        hostButton = setUpButton(new File("./graphics/title-screen/host-button.png"));
        hostButton.setLocation(4 * GamePreferences.getScale(), 33 * GamePreferences.getScale());

        joinButton = setUpButton(new File("./graphics/title-screen/join-button.png"));
        joinButton.setLocation(4 * GamePreferences.getScale(), 57 * GamePreferences.getScale());
    }

    /**
     * Sets up a button, with the given image file.
     *
     * @param file
     *      The file containing the image to use for the button.
     * @return
     *      The created button.
     */
    private ImageButton setUpButton(File file) {
        Image buttonImage = ImageUtilities.loadImage(file);
        buttonImage = ImageUtilities.resizeImage(buttonImage, GamePreferences.getScale());
        ImageButton button = new ImageButton(ImageUtilities.toBufferedImage(buttonImage));

        button.setSize(buttonImage.getWidth(null), buttonImage.getHeight(null));

        add(button, PALETTE_LAYER);
        return button;
    }

    /**
     * Enables or disables the panel, and all of its subviews.
     *
     * @param enabled
     *      True if the panel should be enabled; false if it should be disabled.
     */
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);

        for (Component component : getComponents()) {
            component.setEnabled(enabled);
        }
    }

    /**
     * @return
     *      The 'Host Game' button.
     */
    public ImageButton getHostButton() {
        return hostButton;
    }

    /**
     * @return
     *      The 'Join Game' button.
     */
    public ImageButton getJoinButton() {
        return joinButton;
    }
}

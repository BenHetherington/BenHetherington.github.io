package view.window;

import view.foundation.ColouredRect;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * A coloured rectangle that can fade in and out.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class FadeRect extends ColouredRect {

    private Timer animationTimer = null;
    private int animationIncrement = 0;
    private Runnable callback = null;

    /**
     * Constructs a fade rectangle.
     *
     * @param colour
     *      The default colour to use.
     */
    public FadeRect(Color colour) {
        super(colour);
    }

    /**
     * @return
     *      True if the rectangle is currently fading in or out.
     */
    public boolean isFading() {
        return (animationTimer != null && animationTimer.isRunning());
    }

    /**
     * Sets the callback for when an animation is finished.
     *
     * @param callback
     *      The new callback.
     */
    public void setCallback(Runnable callback) {
        this.callback = callback;
    }

    /**
     * Fades the rectangle in.
     *
     * @param milliseconds
     *      The approximate time for the animation.
     */
    public void fadeIn(int milliseconds) {
        animationIncrement = calculateAnimationIncrement(milliseconds);
        setUpAnimation();
    }

    /**
     * Fades the rectangle out.
     *
     * @param milliseconds
     *      The approximate time for the animation.
     */
    public void fadeOut(int milliseconds) {
        animationIncrement = -calculateAnimationIncrement(milliseconds);
        setUpAnimation();
    }

    /**
     * Calculates the increment to use for each frame.
     *
     * @param milliseconds
     *      The animation time.
     * @return
     *      The increment to use.
     */
    private int calculateAnimationIncrement(int milliseconds) {
        return (255 / (60 * milliseconds / 1000));
    }

    /**
     * Sets up an animation.
     */
    private void setUpAnimation() {
        if (animationTimer != null && animationTimer.isRunning()) {
            animationTimer.stop();
            if (callback != null) {
                callback.run();
            }
        }

        animationTimer = new Timer(1000 / 60, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateAnimation();
            }
        });
        animationTimer.setCoalesce(false);
        animationTimer.start();
    }

    /**
     * Updates the animation for a new frame.
     */
    private void updateAnimation() {
        int alpha = getBackground().getAlpha();
        alpha += animationIncrement;

        if (alpha < 0) {
            alpha = 0;
            animationTimer.stop();

        } else if (alpha > 255) {
            alpha = 255;
            animationTimer.stop();
        }

        int r = getBackground().getRed();
        int g = getBackground().getGreen();
        int b = getBackground().getBlue();
        setBackground(new Color(r, g, b, alpha));

        if (!animationTimer.isRunning()) {
            if (callback != null) {
                callback.run();
            }
        }
    }

}

package view.window;

import common.GamePreferences;
import view.map.GameViewport;
import view.status.StatusView;

import javax.swing.*;
import java.awt.*;

/**
 * The game content panel, containing the game viewport and the status view.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class GameContentPanel extends JPanel {

    private GameViewport gameViewport = new GameViewport(7, 7, 5, 5);
    private StatusView statusView = new StatusView();

    /**
     * Constructs a new game content panel.
     */
    public GameContentPanel() {
        // TODO: Would be nice to make this dynamic
        Dimension size = new Dimension(80 * GamePreferences.getScale(), 104 * GamePreferences.getScale());
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        setBackground(Color.BLACK);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(gameViewport);
        add(statusView);
    }

    /**
     * @return
     *      The status view.
     */
    public StatusView getStatusView() {
        return statusView;
    }

    /**
     * @return
     *      The game viewport.
     */
    public GameViewport getGameViewport() {
        return gameViewport;
    }
}

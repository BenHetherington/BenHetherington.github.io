package view.window;

import common.GamePreferences;
import common.image.ImageUtilities;
import view.controls.ControlPanel;
import view.player.Sprites;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The main window for Dungeon of Doom.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class MainWindow extends JFrame {

    private MenuBar menuBar = new MenuBar();
    private JPanel contentsPane = new JPanel();
    private ControlPanel controlPanel = new ControlPanel();
    private JLayeredPane layeredPane = new JLayeredPane();
    private GameContentPanel gameContentPanel = new GameContentPanel();
    private TitleScreen titleScreen = new TitleScreen();
    private FadeRect fadeRect = new FadeRect(new Color(0, 0, 0, 0));

    /**
     * Constructs the main window.
     */
    public MainWindow() {
        super("Dungeon of Doom");
        setUpWindow();

        pack();
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    /**
     * Sets up the main window.
     */
    private void setUpWindow() {
        setResizable(false);
        setBackground(Color.BLACK);

        contentsPane.setLayout(new BoxLayout(contentsPane, BoxLayout.Y_AXIS));
        setJMenuBar(menuBar);

        fadeRect.setSize(gameContentPanel.getSize());
        fadeRect.setPreferredSize(gameContentPanel.getPreferredSize());
        layeredPane.add(fadeRect, JLayeredPane.MODAL_LAYER);

        layeredPane.setSize(gameContentPanel.getSize());
        layeredPane.setPreferredSize(gameContentPanel.getPreferredSize());
        layeredPane.setMinimumSize(gameContentPanel.getMinimumSize());
        layeredPane.setMaximumSize(gameContentPanel.getMaximumSize());

        contentsPane.add(layeredPane);
        if (GamePreferences.isControlsShown()) {
            contentsPane.add(controlPanel);
        }

        add(contentsPane);
    }

    /**
     * Sets up the main menu UI.
     */
    public void setUpMainMenuUI() {
        layeredPane.remove(gameContentPanel);
        layeredPane.add(titleScreen, JLayeredPane.DEFAULT_LAYER);
    }

    /**
     * Sets up the game UI.
     */
    public void setUpGameUI() {
        layeredPane.remove(titleScreen);
        layeredPane.add(gameContentPanel, JLayeredPane.DEFAULT_LAYER);
    }

    /**
     * Shows or hides the control panel.
     *
     * @param visible
     *      True if the controls should be shown; false otherwise.
     */
    public void displayControls(boolean visible) {
        if (visible) {
            contentsPane.add(controlPanel);
        } else {
            contentsPane.remove(controlPanel);
        }

        revalidate();
        repaint();
        pack();
    }

    /**
     * @return
     *      The control panel.
     */
    public ControlPanel getControlPanel() {
        return controlPanel;
    }

    /**
     * @return
     *      The game content panel.
     */
    public GameContentPanel getGameContentPanel() {
        return gameContentPanel;
    }

    /**
     * @return
     *      The fade rectangle.
     */
    public FadeRect getFadeRect() {
        return fadeRect;
    }

    /**
     * @return
     *      The title screen.
     */
    public TitleScreen getTitleScreen() {
        return titleScreen;
    }

    /**
     * @return
     *      The menu bar.
     */
    public MenuBar getMyMenuBar() {
        // This is named as such, since JWindows already have a getMenuBar() method.
        return menuBar;
    }

}

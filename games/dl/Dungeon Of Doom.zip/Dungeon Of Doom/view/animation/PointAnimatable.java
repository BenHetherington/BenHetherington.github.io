package view.animation;

import java.awt.*;

/**
 * An interface for a UI element that can have its movement animated.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 * @see     PointAnimator
 */
public interface PointAnimatable {

    /**
     * @return
     *      The current position of the UI element.
     */
    Point getPoint();

    /**
     * Sets the position of the UI element.
     *
     * @param newPosition
     *      The new position.
     */
    void setPoint(Point newPosition);

    /**
     * @return
     *      The destination point, after the animation is complete.
     */
    Point getDestinationPoint();

    /**
     * Sets the destination point.
     *
     * @param newPosition
     *      The new destination point.
     */
    void setDestinationPoint(Point newPosition);

    void repaint();

}

package view.animation;

import common.GamePreferences;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Queue;
import java.util.ArrayDeque;

/**
 * Animates a UI element's movement.
 * This also abides by the UI scale.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 * @see     PointAnimatable
 */
public class PointAnimator {

    private PointAnimatable target;
    private Timer timer;
    private Runnable callback;

    private Queue<int[]> scheduledAnimations = new ArrayDeque<>();

    private int updatesLeft;
    private int xIncrement;
    private int yIncrement;
    private int xRoundingError;
    private int yRoundingError;

    /**
     * Constructs a new point animator.
     *
     * @param target
     *      The object to be animated.
     */
    public PointAnimator(PointAnimatable target) {
        this.target = target;

        if (target.getDestinationPoint() == null) {
            target.setDestinationPoint(target.getPoint());
        }
    }

    /**
     * @return
     *      True if the animation is in progress.
     */
    public boolean isAnimating() {
        if (timer != null) {
            return timer.isRunning();
        } else {
            return false;
        }
    }

    /**
     * Sets the callback, for when an animation is finished.
     *
     * @param callback
     *      The new callback.
     */
    public void setCallback(Runnable callback) {
        this.callback = callback;
    }

    /**
     * Stops an animation, if it's in progress.
     */
    public void stop() {
        scheduledAnimations.clear();

        if (timer != null) {
            timer.stop();
        }
    }

    /**
     * Starts an animation.
     *
     * @param origin
     *      The point to animate to.
     * @param milliseconds
     *      The approximate time for the animation.
     */
    public void start(Point origin, int milliseconds) {
        start(origin.x - target.getPoint().x, origin.y - target.getPoint().y, milliseconds);
    }

    /**
     * Starts an animation.
     *
     * @param dxUnscaled
     *      The amount to move the object horizontally.
     * @param dyUnscaled
     *      The amount to move the object vertically.
     * @param milliseconds
     *      The approximate time for the animation.
     */
    public void start(int dxUnscaled, int dyUnscaled, int milliseconds) {
        if (timer != null && timer.isRunning()) {
            int[] parameters = {dxUnscaled, dyUnscaled, milliseconds};
            scheduledAnimations.add(parameters);
            return;
        }

        setUpAnimation(dxUnscaled, dyUnscaled, milliseconds);
    }

    /**
     * Sets up the animation.
     *
     * @param dxUnscaled
     *      The amount to move the object horizontally.
     * @param dyUnscaled
     *      The amount to move the object vertically.
     * @param milliseconds
     *      The approximate time for the animation.
     */
    private void setUpAnimation(int dxUnscaled, int dyUnscaled, int milliseconds) {
        target.setDestinationPoint(new Point(target.getDestinationPoint().x + dxUnscaled,
                target.getDestinationPoint().y + dyUnscaled));

        int dx = dxUnscaled / GamePreferences.getScale();
        int dy = dyUnscaled / GamePreferences.getScale();

        updatesLeft = (milliseconds * 60) / 1000;
        xIncrement = dx / updatesLeft;
        yIncrement = dy / updatesLeft;

        xRoundingError = dxUnscaled - (xIncrement * updatesLeft * GamePreferences.getScale());
        yRoundingError = dyUnscaled - (yIncrement * updatesLeft * GamePreferences.getScale());

        timer = new Timer(1000 / 60, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateAnimation();
            }
        });
        timer.setCoalesce(false);
        timer.start();
    }

    /**
     * Schedules the next animation, if needed.
     */
    private void scheduleNext() {
        if (scheduledAnimations.size() > 0) {
            int[] parameters = scheduledAnimations.poll();
            setUpAnimation(parameters[0], parameters[1], parameters[2]);
        }
    }

    /**
     * Updates the animation for a new frame.
     */
    private void updateAnimation() {
        Point origin = new Point(target.getPoint());
        origin.x += xIncrement * GamePreferences.getScale();
        origin.y += yIncrement * GamePreferences.getScale();

        updatesLeft--;
        target.setPoint(origin);

        if (updatesLeft <= 0) {
            timer.stop();
            origin.x += xRoundingError;
            origin.y += yRoundingError;
            target.setPoint(origin);

            scheduleNext();
            if (callback != null) {
                callback.run();
            }
        }

        target.repaint();
    }

}

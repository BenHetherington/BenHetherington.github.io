package view.map;

import common.Tile;
import view.animation.*;

import javax.swing.*;
import java.awt.*;

/**
 * A wrapper for TileMap, that allows it to scroll.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 * @see     TileMap
 * @see     TileView
 */
public class ScrollingMap extends JViewport implements PointAnimatable {

    private TileMap map;

    private PointAnimator animator = new PointAnimator(this);
    private Point destinationPoint;

    /**
     * Constructs a new scrolling map.
     *
     * @param mapWidth
     *      The width, in tiles, of the underlying map.
     * @param mapHeight
     *      The height, in tiles, of the underlying map.
     * @param visibleWidth
     *      The width, in tiles, of the visible area of the map.
     * @param visibleHeight
     *      The height, in tiles, of the visible area of the map.
     */
    public ScrollingMap(int mapWidth, int mapHeight, int visibleWidth, int visibleHeight) {
        map = new TileMap(mapWidth, mapHeight);
        add(map);
        setVisibleDimensions(visibleWidth, visibleHeight);
    }

    /**
     * Sets the dimensions of the underlying map.
     *
     * @param width
     *      The new width, in tiles.
     * @param height
     *      The new height, in tiles.
     */
    public void setMapDimensions(int width, int height) {
        map.setDimensions(width, height);
    }

    /**
     * Sets the size of the visible area of the map.
     *
     * @param width
     *      The new width, in tiles.
     * @param height
     *      The new height, in tiles.
     */
    public void setVisibleDimensions(int width, int height) {
        int pixelWidth = TileView.TILE_SIZE * width;
        int pixelHeight = TileView.TILE_SIZE * height;

        Dimension size = new Dimension(pixelWidth, pixelHeight);
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
    }

    /**
     * Sets a tile in the map.
     *
     * @param x
     *      The x-coordinate of the tile.
     * @param y
     *      The y-coordinate of the tile.
     * @param tile
     *      The new tile.
     * @param obeyLock
     *      Should usually be true; setting to false will ignore if map updates should be made.
     */
    public void setTile(int x, int y, Tile tile, boolean obeyLock) {
        map.setTile(x, y, tile, obeyLock);
    }

    /**
     * Sets a tile in the map.
     *
     * @param x
     *      The x-coordinate of the tile.
     * @param y
     *      The y-coordinate of the tile.
     * @param tile
     *      The new tile.
     */
    public void setTile(int x, int y, Tile tile) {
        map.setTile(x, y, tile);
    }

    /**
     * Gets a tile from the map.
     *
     * @param x
     *      The x-coordinate of the tile.
     * @param y
     *      The y-coordinate of the tile.
     * @return
     *      The retrieved tile.
     */
    public Tile getTile(int x, int y) {
        return map.getTile(x, y);
    }

    /**
     * Enables or disables updates to the map.
     *
     * @param allowUpdates
     *      True if updates should be enabled; false otherwise.
     */
    public void setAllowUpdates(boolean allowUpdates) {
        map.setAllowUpdates(allowUpdates);
    }

    /**
     * If setAllowUpdates(false) is called, wait until setAllowUpdates(true) is called.
     */
    public void waitUntilUpdatesAreAllowed() {
        map.waitUntilUpdatesAreAllowed();
    }

    /**
     * Immediately scrolls to the given position.
     *
     * @param origin
     *      The position to move to the top-left corner.
     */
    public void scroll(Point origin) {
        if (animator.isAnimating()) {
            animator.stop();
        }

        setViewPosition(origin);
    }

    /**
     * Animates a scroll in a given direction.
     *
     * @param dxUnscaled
     *      The horizontal change.
     * @param dyUnscaled
     *      The vertical change.
     * @param milliseconds
     *      The approximate time for the animation.
     */
    public void animateScroll(int dxUnscaled, int dyUnscaled, int milliseconds) {
        animator.start(dxUnscaled, dyUnscaled, milliseconds);
    }

    /**
     * Sets the callback for after the animation is completed.
     *
     * @param callback
     *      The new callback.
     */
    public void setAnimationCallback(Runnable callback) {
        animator.setCallback(callback);
    }

    /**
     * @return
     *      True if the scrolling animation is in progress; false otherwise.
     */
    public boolean isAnimating() {
        return animator.isAnimating();
    }

    /**
     * {@inheritDoc}
     */
    public Point getPoint() {
        return getViewPosition();
    }

    /**
     * {@inheritDoc}
     */
    public void setPoint(Point newPosition) {
        setViewPosition(newPosition);
    }

    /**
     * {@inheritDoc}
     */
    public Point getDestinationPoint() {
        return destinationPoint;
    }

    /**
     * {@inheritDoc}
     */
    public void setDestinationPoint(Point destinationPoint) {
        this.destinationPoint = destinationPoint;
    }
}

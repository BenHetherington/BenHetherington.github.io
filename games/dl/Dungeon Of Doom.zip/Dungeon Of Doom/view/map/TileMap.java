package view.map;

import common.Tile;
import common.array.*;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.CountDownLatch;

/**
 * A static map, containing Tile Views.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 * @see     TileView
 */
public class TileMap extends JComponent {

    private ArrayList2D<TileView> tiles = new ArrayList2D<>();
    private CountDownLatch allowUpdatesLatch = new CountDownLatch(0);

    private int width;
    private int height;

    /**
     * Constructs a new tile view.
     *
     * @param width
     *      The width, in tiles, of the map.
     * @param height
     *      The height, in tiles, of the map.
     */
    public TileMap(int width, int height) {
        super();

        tiles.setDefaultElement(new DefaultElementCallback<TileView>() {
            public TileView getNextDefaultElement() {
                return new TileView();
            }
        });

        setDimensions(width, height);
    }

    /**
     * Sets the dimensions of the map.
     *
     * @param width
     *      The width, in tiles, of the map.
     * @param height
     *      The height, in tiles, of the map.
     */
    public void setDimensions(int width, int height) {
        if (width < 1 || height < 1) {
            throw new IllegalArgumentException("Dimensions must be positive.");
        }

        this.width = width;
        this.height = height;

        setLayout(new GridLayout(width, height));

        Dimension size = new Dimension(width * TileView.TILE_SIZE, height * TileView.TILE_SIZE);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
        // TODO: Could refactor this to override the getters instead

        tiles.ensureDimensions(width, height);
        addTilesToLayout();
    }

    /**
     * Sets a tile at a given position.
     *
     * @param x
     *      The x-coordinate of the tile.
     * @param y
     *      The y-coordinate of the tile.
     * @param tile
     *      The new tile.
     */
    public void setTile(int x, int y, Tile tile) {
        this.setTile(x, y, tile, true);
    }

    /**
     * Sets a tile at a given position.
     *
     * @param x
     *      The x-coordinate of the tile.
     * @param y
     *      The y-coordinate of the tile.
     * @param tile
     *      The new tile.
     * @param obeyLock
     *      If true, this thread will be blocked if setUpdateAllowed(false) was called,
     *      until setUpdatesAllowed(true) is subsequently called.
     */
    public void setTile(int x, int y, Tile tile, boolean obeyLock) {
        if (obeyLock) {
            waitUntilUpdatesAreAllowed();
        }
        tiles.get(x, y).setTile(tile);
    }

    /**
     * Retrieves a tile at a given coordinate.
     *
     * @param x
     *      The x-coordinate of the tile.
     * @param y
     *      The y-coordinate of the tile.
     * @return
     *      The tile at that position.
     */
    public Tile getTile(int x, int y) {
        return tiles.get(x, y).getTile();
    }

    /**
     * Adds all of the tile views to this map.
     */
    private void addTilesToLayout() {
        removeAll();

        for (int i = 0; i < tiles.getHeight(); i++) {
            for (int j = 0; j < tiles.getWidth(); j++) {
                add(tiles.get(j, i));
            }
        }
    }

    /**
     * Enables or disables the map from being updated. If disabled, subsequent attempts
     * to modify the map will cause the thread to be blocked, until updates are re-enabled.
     *
     * @param allowUpdates
     *      True if the map should be modifiable, false otherwise.
     */
    public synchronized void setAllowUpdates(boolean allowUpdates) {
        if (allowUpdates) {
            allowUpdatesLatch.countDown();

        } else {
            if (allowUpdatesLatch.getCount() <= 0) {
                allowUpdatesLatch = new CountDownLatch(1);
            }
        }
    }

    /**
     * Blocks the current thread until the map is allowed to be updated.
     */
    public void waitUntilUpdatesAreAllowed() {
        try {
            allowUpdatesLatch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }


}

package view.map;

import common.GamePreferences;
import common.Tile;
import common.image.*;

import javax.swing.*;
import java.awt.*;

/**
 * A view that represents a single tile.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class TileView extends JComponent {

    final public static int TILE_SIZE = 16 * GamePreferences.getScale();
    private static ImageCache<Tile> imageCache = new ImageCache<>(new TileGraphicsFilenameCallback(), GamePreferences.getScale());

    private Tile currentTile;
    private Image currentImage;

    /**
     * Constructs a new tile view.
     */
    public TileView() {
        this(Tile.Wall);
    }

    /**
     * Constructs a new tile view.
     *
     * @param tile
     *      The tile for this view to represent.
     */
    public TileView(Tile tile) {
        super();

        Dimension size = new Dimension(TILE_SIZE, TILE_SIZE);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
        // TODO: Override the getters instead?

        setTile(tile);
    }

    /**
     * Sets the tile that this view represents.
     *
     * @param tile
     *      The new tile.
     */
    public void setTile(Tile tile) {
        currentTile = tile;
        currentImage = imageCache.getGraphic(tile);
        repaint();
    }

    /**
     * @return
     *      The tile that this view represents.
     */
    public Tile getTile() {
        return currentTile;
    }

    /**
     * {@inheritDoc}
     */
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(currentImage, 0, 0, null);
    }
}

/**
 * Returns the filenames to the graphics for all of the tiles.
 */
class TileGraphicsFilenameCallback implements ImageFilenameCallback<Tile> {

    public String getImageFilename(Tile element) {
        switch (element) {
            case Empty:
                return "./graphics/tiles/empty.png";

            case Wall:
                return "./graphics/tiles/wall.png";

            case Gold:
                return "./graphics/tiles/gold.png";

            case Exit:
                return "./graphics/tiles/exit.png";

            default:
                throw new RuntimeException("Unrecognised Tile Type");
        }
    }

}


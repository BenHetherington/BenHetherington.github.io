package view.map;

import common.GamePreferences;
import view.player.*;

import javax.swing.*;
import java.awt.*;
import java.util.*;

/**
 * The game's viewport. Layers all of the player sprites on top of the scrolling map.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class GameViewport extends JLayeredPane {

    private ScrollingMap map;
    private Map<Byte, PlayerView> playerViews = new HashMap<>();

    /**
     * @return
     *      The map.
     */
    public ScrollingMap getMap() {
        return map;
    }

    /**
     * Adds a new player to the viewport.
     *
     * @param playerID
     *      The player's ID.
     * @param character
     *      The player's character.
     * @return
     *      The new player view.
     */
    public PlayerView addPlayerView(Byte playerID, Characters character) {
        PlayerView newPlayer = new PlayerView(character);
        playerViews.put(playerID, newPlayer);

        newPlayer.setPoint(new Point(-PlayerView.SPRITE_SIZE, -PlayerView.SPRITE_SIZE));
        newPlayer.setDestinationPoint(new Point(-PlayerView.SPRITE_SIZE, -PlayerView.SPRITE_SIZE));

        add(newPlayer, JLayeredPane.PALETTE_LAYER);
        repaint();
        return newPlayer;
    }

    /**
     * Gets the player view associated with the given ID.
     *
     * @param playerID
     *      The player ID associated with the desired player view.
     * @return
     *      The player view.
     */
    public PlayerView getPlayerView(Byte playerID) {
        return playerViews.get(playerID);
    }

    /**
     * @return
     *      All of the player IDs of the current player views.
     */
    public Set<Byte> getPlayerViewKeys() {
        return playerViews.keySet();
    }

    /**
     * Removes the player view associated with the given ID.
     *
     * @param playerID
     *      The player ID associated with the player view to remove.
     */
    public void removePlayerView(Byte playerID) {
        if (playerViews.containsKey(playerID)) {
            remove(playerViews.get(playerID));
            repaint();
            playerViews.remove(playerID);
        }
    }

    /**
     * Sets the dimensions of the map.
     *
     * @param width
     *      The width, in tiles, of the map.
     * @param height
     *      The height, in tiles, of the map.
     */
    public void setDimensions(int width, int height) {
        map.setMapDimensions(width + 2, height + 2);
        map.setVisibleDimensions(width, height);
        map.scroll(new Point(TileView.TILE_SIZE, TileView.TILE_SIZE));

        setSize(map.getSize());
        setPreferredSize(map.getPreferredSize());
        setMinimumSize(map.getMinimumSize());
        setMaximumSize(map.getMaximumSize());
    }

    /**
     * Construts a new game viewport.
     *
     * @param mapWidth
     *      The width, in tiles, of the underlying map.
     * @param mapHeight
     *      The height, in tiles, of the underlying map.
     * @param visibleWidth
     *      The width, in tiles, of the visible area of the map.
     * @param visibleHeight
     *      The height, in tiles, of the visible area of the map.
     */
    public GameViewport(int mapWidth, int mapHeight, int visibleWidth, int visibleHeight) {
        // TODO: It'd be nice if this could be dynamic
        Dimension size = new Dimension(80 * GamePreferences.getScale(), 80 * GamePreferences.getScale());
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        map = new ScrollingMap(mapWidth, mapHeight, visibleWidth, visibleHeight);
        add(map, JLayeredPane.DEFAULT_LAYER);
    }

}

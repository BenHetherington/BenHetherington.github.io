package view.foundation;

import common.image.ImageUtilities;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;

/**
 * A button that is represented by an image.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 * @see     CustomButton
 */
public class ImageButton extends CustomButton {

    private BufferedImage image;

    /**
     * Constructs a new image button.
     *
     * @param image
     *      The image to use.
     */
    public ImageButton(BufferedImage image) {
        setImage(image);
    }

    /**
     * Sets the button's image.
     *
     * @param image
     *      The image to use.
     */
    public void setImage(BufferedImage image) {
        this.image = image;
        setSize(getPreferredSize());
    }

    /**
     * {@inheritDoc}
     */
    protected void paintComponent(Graphics g) {
        BufferedImage image = this.image;

        if (model.isArmed()) {
            HashMap<Integer, Integer> recolourMap = new HashMap<>();
            recolourMap.put(0xFFFEFFFF, 0xFF999999);
            image = ImageUtilities.recolourImage(image, recolourMap);
        }

        g.drawImage(image, 0, 0, null);
    }

    public Dimension getPreferredSize() {
        return new Dimension(image.getWidth(), image.getHeight());
    }

    public Dimension getMinimumSize() {
        return getPreferredSize();
    }

    public Dimension getMaximumSize() {
        return getPreferredSize();
    }
}

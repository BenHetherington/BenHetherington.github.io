package view.foundation;

import javax.swing.*;

/**
 * A custom button, that doesn't draw a border, and cannot be focused on.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public abstract class CustomButton extends JButton {

    /**
     * Constructs a custom button.
     */
    public CustomButton() {
        setProperties();
    }

    /**
     * Constructs a custom button.
     *
     * @param text
     *      The text that the button should have.
     */
    public CustomButton(String text) {
        super(text);
        setProperties();
    }

    /**
     * Sets the default properties.
     */
    private void setProperties() {
        setBorderPainted(false);
        setOpaque(false);
        setFocusable(false);
    }

}

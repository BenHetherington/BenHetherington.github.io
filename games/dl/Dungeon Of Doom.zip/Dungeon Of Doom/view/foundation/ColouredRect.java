package view.foundation;

import javax.swing.*;
import java.awt.*;

/**
 * A rectangle, with a custom colour.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class ColouredRect extends JComponent {

    /**
     * Constructs a coloured rectangle.
     *
     * @param colour
     *      The colour of this rectangle.
     */
    public ColouredRect(Color colour) {
        setBackground(colour);
    }

    /**
     * Sets the colour of this rectangle.
     *
     * @param colour
     *      The new colour.
     */
    public void setBackground(Color colour) {
        super.setBackground(colour);
        setOpaque(colour.getAlpha() == 255);
    }

    /**
     * {@inheritDoc}
     */
    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }

}

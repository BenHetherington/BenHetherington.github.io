package view.status;

import common.GamePreferences;
import common.image.ImageUtilities;
import view.foundation.ColouredRect;

import javax.swing.*;
import java.awt.*;
import java.io.*;

/**
 * The status view, as displayed below the game viewport.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class StatusView extends JPanel {

    private ColouredRect separator = new ColouredRect(new Color(86, 86, 86));
    private GoldDisplay goldDisplay = new GoldDisplay();
    private JLabel lines;
    private JLabel image = new JLabel();
    private boolean imageIsBeingDisplayed = false;

    /**
     * Constructs a new status view.
     */
    public StatusView() {
        setLayout(null); // We'll do the layout ourselves
        setPreferredSize(new Dimension(80 * GamePreferences.getScale(), 24 * GamePreferences.getScale()));
        setMinimumSize(new Dimension(57 * GamePreferences.getScale(), 24 * GamePreferences.getScale()));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 24 * GamePreferences.getScale()));
        setBackground(Color.BLACK);

        separator.setLocation(0, 0);
        add(separator);

        Image linesImage = ImageUtilities.loadImage(new File("./graphics/status/lines.png"));
        linesImage = ImageUtilities.resizeImage(linesImage, GamePreferences.getScale());
        lines = new JLabel(new ImageIcon(linesImage));
        lines.setSize(linesImage.getWidth(null), linesImage.getHeight(null));
        add(lines);

        add(goldDisplay);
    }

    /**
     * @return
     *      This status view's gold display.
     */
    public GoldDisplay getGoldDisplay() {
        return goldDisplay;
    }

    /**
     * Replaces the status view with an image.
     *
     * @param image
     *      The image to overlay, or null to reset to normal.
     */
    public void setImage(Image image) {
        if (image == null) {
            if (imageIsBeingDisplayed) {
                remove(this.image);
                add(lines);
                add(goldDisplay);
                imageIsBeingDisplayed = false;
            }

        } else {
            this.image.setIcon(new ImageIcon(image));

            if (!imageIsBeingDisplayed) {
                add(this.image);
                remove(lines);
                remove(goldDisplay);
                imageIsBeingDisplayed = true;
            }
        }

        validate();
        repaint();
    }

    /**
     * Displays a message in the status view.
     *
     * @param text
     *      The text to display.
     */
    public void setText(String text) {
        if (text != null) {
            Image image = ImageUtilities.generateTextImage(text, getWidth() / GamePreferences.getScale(),
                    getHeight() / GamePreferences.getScale(), 9f, Color.BLACK, Color.WHITE);
            setImage(ImageUtilities.resizeImage(image, GamePreferences.getScale()));

        } else {
            setImage(null);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void doLayout() {
        super.doLayout();
        separator.setSize(getWidth(), GamePreferences.getScale());

        if (!imageIsBeingDisplayed) {
            goldDisplay.setLocation(3 * GamePreferences.getScale(), 9 * GamePreferences.getScale());

            if (getWidth() > 74 * GamePreferences.getScale()) {
                lines.setLocation(getWidth() - lines.getWidth(), getHeight() - lines.getHeight());
            } else {
                lines.setLocation(74 * GamePreferences.getScale(), getHeight() - lines.getHeight());
            }

        } else {
            image.setBounds(0, GamePreferences.getScale(), getWidth(), getHeight() - GamePreferences.getScale());

        }
    }

}

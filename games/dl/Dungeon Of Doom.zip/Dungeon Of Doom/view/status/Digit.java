package view.status;

import common.GamePreferences;
import common.image.*;

import javax.swing.*;
import java.awt.*;

/**
 * Represents a single digit, as used in the gold display.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 * @see     GoldDisplay
 */
public class Digit extends JComponent {

    int value = 0;
    boolean isBig;

    private Image image;
    private static ImageCache<Integer> imageCache = new ImageCache<>(new DigitGraphicsCallback(), 1);

    /**
     * Constructs a new digit.
     *
     * @param isBig
     *      True if the sprite should be doubled in size.
     */
    public Digit(boolean isBig) {
        this.isBig = isBig;

        Dimension size = new Dimension(3 * GamePreferences.getScale(), 5 * GamePreferences.getScale());

        if (isBig) {
            size.width *= 2;
            size.height *= 2;
        }

        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        setValue(0);
    }

    /**
     * @return
     *      The value represented by this digit.
     */
    public int getValue() {
        return value;
    }

    /**
     * Sets the digit represented by this digit.
     *
     * @param value
     *      The digit's new value.
     */
    public void setValue(int value) {
        this.value = value % 10;
        image = imageCache.getGraphic(this.value);

        if (isBig) {
            image = ImageUtilities.resizeImage(image, GamePreferences.getScale() * 2);
        } else {
            image = ImageUtilities.resizeImage(image, GamePreferences.getScale());
        }

        repaint();
    }

    /**
     * {@inheritDoc}
     */
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
    }
}

/**
 * Returns the filename for one of the digit graphics.
 */
class DigitGraphicsCallback implements ImageFilenameCallback<Integer> {

    public String getImageFilename(Integer element) {
        return "./graphics/status/digits/" + element + ".png";
    }

}

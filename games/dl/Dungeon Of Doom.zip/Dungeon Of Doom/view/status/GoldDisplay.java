package view.status;

import common.GamePreferences;
import common.image.ImageUtilities;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * Displays the amount of gold collected, and the amount of gold needed.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 * @see     Digit
 */
public class GoldDisplay extends JComponent {

    JLabel goldIcon;
    JLabel cross;
    JLabel separator;

    Digit[] collectedDigits = {new Digit(true),  new Digit(true)};
    Digit[] neededDigits    = {new Digit(false), new Digit(false)};

    /**
     * Constructs a new gold display.
     */
    public GoldDisplay() {
        setLayout(null);

        Dimension size = new Dimension(49 * GamePreferences.getScale(), 12 * GamePreferences.getScale());
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        Image goldImage = ImageUtilities.loadImage(new File("./graphics/status/gold.png"));
        goldIcon = new JLabel(new ImageIcon(ImageUtilities.resizeImage(goldImage, GamePreferences.getScale())));
        goldIcon.setBounds(0, 0, 12 * GamePreferences.getScale(), 12 * GamePreferences.getScale());
        add(goldIcon);

        Image crossImage = ImageUtilities.loadImage(new File("./graphics/status/cross.png"));
        cross = new JLabel(new ImageIcon(ImageUtilities.resizeImage(crossImage, GamePreferences.getScale())));
        cross.setBounds(14 * GamePreferences.getScale(), 6 * GamePreferences.getScale(), 5 * GamePreferences.getScale(), 5 * GamePreferences.getScale());
        add(cross);

        Image separatorImage = ImageUtilities.loadImage(new File("./graphics/status/separator.png"));
        separator = new JLabel(new ImageIcon(ImageUtilities.resizeImage(separatorImage, GamePreferences.getScale())));
        separator.setBounds(37 * GamePreferences.getScale(), 5 * GamePreferences.getScale(), 3 * GamePreferences.getScale(), 6 * GamePreferences.getScale());
        add(separator);

        collectedDigits[0].setLocation(21 * GamePreferences.getScale(), GamePreferences.getScale());
        add(collectedDigits[0]);
        collectedDigits[1].setLocation(29 * GamePreferences.getScale(), GamePreferences.getScale());
        add(collectedDigits[1]);

        neededDigits[0].setLocation(42 * GamePreferences.getScale(), 6 * GamePreferences.getScale());
        add(neededDigits[0]);
        neededDigits[1].setLocation(46 * GamePreferences.getScale(), 6 * GamePreferences.getScale());
        add(neededDigits[1]);
    }

    /**
     * Sets the amount of gold that has been collected.
     *
     * @param collectedCount
     *      The new value.
     */
    public void setCollectedCount(int collectedCount) {
        if (collectedCount > 99) {
            collectedCount = 99;
        } else if (collectedCount < 0) {
            collectedCount = 0;
        }

        collectedDigits[0].setValue(collectedCount / 10);
        collectedDigits[1].setValue(collectedCount % 10);
    }

    /**
     * Sets the amount of gold needed to win.
     *
     * @param neededCount
     *      The new value.
     */
    public void setNeededCount(int neededCount) {
        if (neededCount > 99) {
            neededCount = 99;
        } else if (neededCount < 0) {
            neededCount = 0;
        }

        neededDigits[0].setValue(neededCount / 10);
        neededDigits[1].setValue(neededCount % 10);
    }

}

package view.controls;

import view.foundation.CustomButton;

import java.awt.*;
import java.util.Locale;

/**
 * A pickup button.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class PickupButton extends CustomButton {

    /**
     * Constructs a pickup button.
     */
    public PickupButton() {
        this("Pickup");
    }

    /**
     * Constructs a pickup button.
     *
     * @param text
     *      The text to use.
     */
    public PickupButton(String text) {
        super(text);

        Dimension size = new Dimension(45, 45);
        setSize(size);
        setPreferredSize(size);
    }

    /**
     * {@inheritDoc}
     */
    protected void paintComponent(Graphics g) {
        if (g instanceof Graphics2D) {
            ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }

        g.setColor(model.isPressed() ? getBackground().darker() : getBackground());
        g.fillOval(0, 0, getWidth(), getHeight());

        g.setColor(Color.DARK_GRAY);
        g.drawOval(0, 0, getWidth(), getHeight());

        g.setColor(model.isEnabled() ? Color.BLACK : Color.LIGHT_GRAY);
        g.setFont(g.getFont().deriveFont(10f));
        String text = getText().toUpperCase(Locale.getDefault());

        FontMetrics metrics = g.getFontMetrics(g.getFont());
        int xOffset = (int)Math.ceil((getWidth() - metrics.getStringBounds(text, g).getWidth()) / 2);
        int yOffset = (int)((getHeight() - metrics.getStringBounds(text, g).getHeight()) / 2  + (metrics.getAscent()));

        g.drawString(text, xOffset, yOffset);
    }
}

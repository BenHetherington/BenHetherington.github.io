package view.controls;

import javax.swing.*;
import java.awt.*;

/**
 * The controls panel, since apparently some people like using a "mouse" to play this kind of game.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class ControlPanel extends JPanel {

    private MovePanel movePanel = new MovePanel();
    private QuitButton quitButton = new QuitButton();
    private PickupButton pickupButton = new PickupButton();

    /**
     * Constructs a new control panel.
     */
    public ControlPanel() {
        setBackground(Color.BLACK); // Experiment

        add(movePanel);
        add(quitButton);
        add(pickupButton);

        setEnabled(false);
    }

    /**
     * @return
     *      The move panel.
     */
    public MovePanel getMovePanel() {
        return movePanel;
    }

    /**
     * @return
     *      The quit button.
     */
    public QuitButton getQuitButton() {
        return quitButton;
    }

    /**
     * @return
     *      The pickup button.
     */
    public PickupButton getPickupButton() {
        return pickupButton;
    }

    /**
     * Enables or disables the panel, and all of its subviews.
     *
     * @param enabled
     *      True if the panel should be enabled; false if it should be disabled.
     */
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);

        for (Component component : getComponents()) {
            component.setEnabled(enabled);
        }
    }
}

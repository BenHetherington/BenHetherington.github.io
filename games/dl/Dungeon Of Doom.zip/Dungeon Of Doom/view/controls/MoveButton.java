package view.controls;

import view.foundation.CustomButton;
import common.Direction;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Arc2D;

/**
 * A button for moving up, down, left, or right.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class MoveButton extends CustomButton {

    private Direction direction;
    private Arc2D arc;
    private Polygon arrow;

    /**
     * @return
     *      The direction that this button represents.
     */
    public Direction getDirection() {
        return direction;
    }

    /**
     * Constructs a move button.
     *
     * @param direction
     *      The direction that this button represents.
     */
    public MoveButton(Direction direction) {
        this.direction = direction;
        setBackground(Color.WHITE);

        Dimension size = new Dimension(51, 51);
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        int startAngle;

        switch (direction) {
            case Up:
                startAngle = 45;
                arrow = new Polygon(new int[]{4, 0, 8}, new int[]{0, 8, 8}, 3);
                arrow.translate((getWidth() / 2) - 4, (getHeight() / 5) - 4);
                break;

            case Down:
                startAngle = 225;
                arrow = new Polygon(new int[]{4, 0, 8}, new int[]{8, 0, 0}, 3);
                arrow.translate((getWidth() / 2) - 4, (4 * getHeight() / 5) - 4);
                break;

            case Left:
                startAngle = 135;
                arrow = new Polygon(new int[]{0, 8, 8}, new int[]{4, 0, 8}, 3);
                arrow.translate((getWidth() / 5) - 4, (getHeight() / 2) - 4);
                break;

            case Right:
                startAngle = 315;
                arrow = new Polygon(new int[]{8, 0, 0}, new int[]{4, 0, 8}, 3);
                arrow.translate((4 * getWidth() / 5) - 4, (getHeight() / 2) - 4);
                break;

            default:
                throw new IllegalArgumentException("An invalid direction was passed to MoveButton.");
        }

        arc = new Arc2D.Float(0, 0, getWidth() - 1, getHeight() - 1, startAngle, 90, Arc2D.PIE);
    }

    /**
     * Returns true if the given coordinate is within the button.
     *
     * @param x
     *      The x-coordinate to check.
     * @param y
     *      The y-coordinate to check.
     * @return
     *      True if this point is within the button; false otherwise.
     */
    public boolean contains(int x, int y) {
        return arc.contains(x, y);
    }

    /**
     * {@inheritDoc}
     */
    protected void paintComponent(Graphics g) {
        if (g instanceof Graphics2D) {
            Graphics2D g2d = (Graphics2D)g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

            g2d.setColor(Color.DARK_GRAY);
            g2d.draw(arc);

            g2d.setColor(model.isPressed() ? getBackground().darker() : getBackground());
            g2d.fill(arc);

            if (arrow != null) {
                g2d.setColor(model.isEnabled() ? Color.BLACK : Color.LIGHT_GRAY);
                g2d.fill(arrow);
            }
        }
    }
}


package view.controls;

import common.Direction;

import javax.swing.*;
import java.awt.*;
import java.util.*;

/**
 * A panel that contains four move buttons, for moving in any direction.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class MovePanel extends JPanel {

    private Map<Direction, MoveButton> buttons = new HashMap<>();

    /**
     * Constructs a move panel.
     */
    public MovePanel() {
        setLayout(null);
        setOpaque(false);

        Dimension size = new Dimension(51, 51);
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        for (Direction direction : Direction.values()) {
            MoveButton button = new MoveButton(direction);
            buttons.put(direction, button);
            button.setLocation(0, 0);
            add(button);
        }
    }

    /**
     * @return
     *      The map between directions and move buttons.
     */
    public Map<Direction, MoveButton> getButtons() {
        return buttons;
    }

    /**
     * Enables or disables the panel, and all of its subviews.
     *
     * @param enabled
     *      True if the panel should be enabled; false if it should be disabled.
     */
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);

        for (MoveButton button : buttons.values()) {
            button.setEnabled(enabled);
        }
    }

}

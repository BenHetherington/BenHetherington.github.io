package view.controls;

import javax.swing.*;
import java.awt.*;

/**
 * A quit button.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class QuitButton extends JButton {

    /**
     * Constructs a quit button.
     */
    public QuitButton() {
        this("Quit");
    }

    /**
     * Constructs a quit button.
     *
     * @param text
     *      The text to use.
     */
    public QuitButton(String text) {
        super(text);
        setFocusable(false);
        setContentAreaFilled(false);
        setBackground(Color.WHITE);
    }

}

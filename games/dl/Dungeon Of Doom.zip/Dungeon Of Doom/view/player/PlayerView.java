package view.player;

import common.GamePreferences;
import common.image.ImageUtilities;
import view.animation.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

/**
 * A view that represents a player.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class PlayerView extends JComponent implements PointAnimatable {

    final public static int SPRITE_SIZE = 16 * GamePreferences.getScale();
    final private static int FRAME_DELAY = 188;

    private Characters character; // Some kind of reference to the current character
    private Sprites sprite;       // Some kind of reference to the current sprite

    private int xOffset = 0;                // The offset of the sprite sheet to draw from
    private boolean walkFrame = false;      // Some kind of reference to the current animation frame
    private boolean xFlip = false;
    private boolean readyToXFlip = false;

    private Timer frameAnimationTimer;                                          // For alternating between walking frames
    private PointAnimator movementAnimationTimer = new PointAnimator(this);     // For making the player move with the map
    private PointAnimator selfMovementAnimationTimer = new PointAnimator(this); // For making the player move
    private Point destinationPoint;

    private Image spriteSheet;

    /**
     * Constructs a new player view.
     *
     * @param character
     *      The character to use.
     */
    public PlayerView(Characters character) {
        Dimension size = new Dimension(SPRITE_SIZE, SPRITE_SIZE);
        setSize(size);
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);

        setCharacter(character);
        setSprite(Sprites.FaceDown);
    }

    /**
     * Sets the character used by this player view.
     *
     * @param character
     *      The character to use.
     */
    public void setCharacter(Characters character) {
        if (this.character != character) {
            this.character = character;
            spriteSheet = ImageUtilities.loadImage(new File(character.path));
            spriteSheet = ImageUtilities.resizeImage(spriteSheet, GamePreferences.getScale());
            repaint();
        }
    }

    /**
     * @return
     *      The character used by this player view.
     */
    public Characters getCharacter() {
        return character;
    }

    /**
     * Sets the sprite shown.
     *
     * @param sprite
     *      The sprite to show.
     */
    public void setSprite(Sprites sprite) {
        this.sprite = sprite;
        xOffset = sprite.value * SPRITE_SIZE;
        xFlip = false;
        repaint();

        if (sprite.isAnimated) {
            setUpFrameAnimation();

        } else if (frameAnimationTimer != null && frameAnimationTimer.isRunning()) {
            frameAnimationTimer.stop();
        }
    }

    /**
     * @return
     *      The sprite currently being used by this player view.
     */
    public Sprites getSprite() {
        return sprite;
    }

    /**
     * Animates this player moving along with the map.
     *
     * @param dxUnscaled
     *      The amount to move by horizontally.
     * @param dyUnscaled
     *      The amount to move by vertically.
     * @param milliseconds
     *      The approximate amount of time for the animation.
     */
    public void animateMovementWithMap(int dxUnscaled, int dyUnscaled, int milliseconds) {
        movementAnimationTimer.start(dxUnscaled, dyUnscaled, milliseconds);
    }

    /**
     * Animates this player moving themselves.
     *
     * @param dxUnscaled
     *      The amount to move by horizontally.
     * @param dyUnscaled
     *      The amount to move by vertically.
     * @param milliseconds
     *      The approximate amount of time for the animation.
     */
    public void animateSelfMovement(int dxUnscaled, int dyUnscaled, int milliseconds) {
        selfMovementAnimationTimer.start(dxUnscaled, dyUnscaled, milliseconds);
    }

    /**
     * Sets up a sprite animation.
     */
    private void setUpFrameAnimation() {
        if (frameAnimationTimer != null && frameAnimationTimer.isRunning()) {
            frameAnimationTimer.stop();
        }

        walkFrame = true;

        frameAnimationTimer = new Timer(FRAME_DELAY, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doFrameAnimation();
            }
        });
        frameAnimationTimer.start();
    }

    /**
     * Moves to the next frame of a sprite animation.
     */
    private void doFrameAnimation() {
        if (walkFrame) {
            xOffset -= SPRITE_SIZE;
            walkFrame = false;
            xFlip = false;

        } else {
            xOffset += SPRITE_SIZE;
            walkFrame = true;

            if (sprite.xFlippable) {
                if (readyToXFlip) {
                    xFlip = true;
                    readyToXFlip = false;
                } else {
                    xFlip = false;
                    readyToXFlip = true;
                }
            }
        }

        repaint();
    }

    /**
     * {@inheritDoc}
     */
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!xFlip) {
            g.drawImage(spriteSheet, 0, 0, SPRITE_SIZE, SPRITE_SIZE, xOffset, 0, xOffset + SPRITE_SIZE, SPRITE_SIZE, null);
        } else {
            g.drawImage(spriteSheet, SPRITE_SIZE, 0, 0, SPRITE_SIZE, xOffset, 0, xOffset + SPRITE_SIZE, SPRITE_SIZE, null);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Point getPoint() {
        return getLocation();
    }

    /**
     * {@inheritDoc}
     */
    public void setPoint(Point newPosition) {
        setLocation(newPosition);
    }

    /**
     * {@inheritDoc}
     */
    public Point getDestinationPoint() {
        return destinationPoint;
    }

    /**
     * {@inheritDoc}
     */
    public void setDestinationPoint(Point newPosition) {
        destinationPoint = newPosition;
    }
}


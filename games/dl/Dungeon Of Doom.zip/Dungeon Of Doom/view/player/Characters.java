package view.player;

/**
 * Represents all of the available characters in Dungeon of Doom.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public enum Characters {
    Bot("bot"),
    Ethan("ethan"),
    Kris("kris");

    final public byte ID;
    final public String path;

    /**
     * Constructs a new character.
     *
     * @param name
     *      The name of the character.
     */
    Characters(String name) {
        this.ID = (byte)ordinal();
        this.path = "./graphics/players/" + name + ".png";
    }

    /**
     * Retrieves the character with the given value.
     *
     * @param value
     *      The value to use.
     * @return
     *      The character that is represented by that value.
     * @throws ArrayIndexOutOfBoundsException
     *      Thrown if an invalid value is used.
     */
    public static Characters valueOf(int value) throws ArrayIndexOutOfBoundsException {
        return Characters.values()[value];
    }
}

package view.player;

import common.Direction;

/**
 * The available sprites in Dungeon of Doom.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public enum Sprites {
    FaceUp(false, false),
    WalkUp(true, true),
    FaceDown(false, false),
    WalkDown(true, true),
    FaceRight(false, false),
    WalkRight(true, false),
    FaceLeft(false, false),
    WalkLeft(true, false);

    final public byte value;
    final public boolean isAnimated;
    final public boolean xFlippable;

    /**
     * Retrieves the sprite with the given value.
     *
     * @param value
     *      The value to use.
     * @return
     *      The sprite that is represented by that value.
     */
    public static Sprites valueOf(byte value) {
        for (Sprites sprite : Sprites.values()) {
            if (sprite.value == value) {
                return sprite;
            }
        }

        return null;
    }

    /**
     * Gets a sprite, given a direction, and if the player is walking.
     *
     * @param direction
     *      The direction to use.
     * @param isWalking
     *      True if the player is walking; false if they are stationary.
     * @return
     *      The relevant sprite.
     */
    public static Sprites getSprite(Direction direction, boolean isWalking) {
        switch (direction) {
            case Up:
                return isWalking ? Sprites.WalkUp : Sprites.FaceUp;

            case Down:
                return isWalking ? Sprites.WalkDown : Sprites.FaceDown;

            case Left:
                return isWalking ? Sprites.WalkLeft : Sprites.FaceLeft;

            case Right:
                return isWalking ? Sprites.WalkRight : Sprites.FaceRight;

            default:
                return null;
        }
    }

    /**
     * Constructs a sprite.
     *
     * @param isAnimated
     *      True if the sprite is animated.
     * @param xFlippable
     *      True if the sprite can be safely flipped horizontally.
     */
    Sprites(boolean isAnimated, boolean xFlippable) {
        this.value = (byte)ordinal();
        this.isAnimated = isAnimated;
        this.xFlippable = xFlippable;
    }
}

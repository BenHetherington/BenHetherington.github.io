package client;

import common.Tile;
import common.sound.SoundEffect;
import controller.ViewController;
import view.player.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * The event handler for the GUI.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class GUIEventHandler extends EventHandler {

    private ViewController viewController;

    /**
     * Constructs a GUIEventHandler with the given logic object and view controller.
     * @param logic
     *      The client logic to associate with this event handler.
     * @param viewController
     *      The view controller to associate with this event handler.
     */
    public GUIEventHandler(ClientLogic logic, ViewController viewController) {
        super(logic);
        this.viewController = viewController;
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerMoved(final byte playerID, final byte positionX, final byte positionY) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                synchronized (viewController.getGameViewport()) {
                    Point newPosition = new Point(positionX, positionY);
                    PlayerView player = viewController.getGameViewport().getPlayerView(playerID);

                    if (player != null) {
                        // Move the player
                        int difference = (logic.getPlayerAlertRadius() - logic.getViewRadius()) / 2;
                        int dx = ((newPosition.x - difference) * PlayerView.SPRITE_SIZE) - player.getDestinationPoint().x;
                        int dy = ((newPosition.y - difference) * PlayerView.SPRITE_SIZE) - player.getDestinationPoint().y;

                        player.animateSelfMovement(dx, dy, ViewController.MOVE_TIME);

                    } else {
                        // Add the player
                        viewController.getGameViewport().addPlayerView(playerID, Characters.Bot);
                        player = viewController.getGameViewport().getPlayerView(playerID);

                        Point point = new Point((newPosition.x - 1) * PlayerView.SPRITE_SIZE, (newPosition.y - 1) * PlayerView.SPRITE_SIZE);
                        player.setPoint(point);
                        player.setDestinationPoint(point);
                    }
                }
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerOutOfView(final byte playerID) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                synchronized (viewController.getGameViewport()) {
                    viewController.getGameViewport().removePlayerView(playerID);
                }
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerSpriteChanged(final byte playerID, final Characters character, final Sprites sprite) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                synchronized (viewController.getGameViewport()) {
                    viewController.getGameViewport().getPlayerView(playerID).setCharacter(character);
                    viewController.getGameViewport().getPlayerView(playerID).setSprite(sprite);
                }
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handleTileChanged(final byte positionX, final byte positionY, final Tile newTile) {
        viewController.getMap().waitUntilUpdatesAreAllowed();

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                synchronized (viewController.getMap()) {
                    viewController.getMap().setTile(positionX + 1, positionY + 1, newTile);
                }
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handleGoldChanged(final byte collectedGold, final byte neededGold) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                viewController.getGoldDisplay().setCollectedCount(collectedGold);
                viewController.getGoldDisplay().setNeededCount(neededGold);
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handleEntireMapUpdate(final Tile[][] newMap) {
        viewController.getMap().waitUntilUpdatesAreAllowed();

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                synchronized (viewController.getMap()) {
                    for (int i = 0; i < newMap.length; i++) {
                        for (int j = 0; j < newMap.length; j++) {
                            viewController.getMap().setTile(j + 1, i + 1, newMap[i][j]);
                        }
                    }
                }
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handleMapRowUpdate(final byte positionY, final Tile[] newRow) {
        viewController.getMap().waitUntilUpdatesAreAllowed();

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                synchronized (viewController.getMap()) {
                    for (int i = 0; i < newRow.length; i++) {
                        viewController.getMap().setTile(i + 1, positionY + 1, newRow[i]);
                    }
                }
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handleMapColumnUpdate(final byte positionX, final Tile[] newColumn) {
        viewController.getMap().waitUntilUpdatesAreAllowed();

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                synchronized (viewController.getMap()) {
                    for (int i = 0; i < newColumn.length; i++) {
                        viewController.getMap().setTile(positionX + 1, i + 1, newColumn[i]);
                    }
                }
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    protected void handleViewRadiusChanged(byte newViewRadius) {
        super.handleViewRadiusChanged(newViewRadius);
        viewController.getGameViewport().setDimensions(newViewRadius, newViewRadius);
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerAlertRadiusChanged(byte newPlayerAlertRadius) {
        super.handlePlayerAlertRadiusChanged(newPlayerAlertRadius);
    }

    /**
     * {@inheritDoc}
     */
    protected void handleGameFinished(byte winningPlayer) {
        logic.finishGame(winningPlayer);
        final boolean didWin = (winningPlayer == logic.connection.playerID);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                if (didWin) {
                    viewController.getStatusView().setText("YOU WIN!");
                    viewController.getSoundEngine().playSound(SoundEffect.Win);

                } else {
                    viewController.getStatusView().setText("TOO BAD…");
                    viewController.getSoundEngine().playSound(SoundEffect.Lose);
                }

                viewController.getControlPanel().setEnabled(false);

                Timer timer = new Timer(2500, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        viewController.goToMainMenu();
                    }
                });
                timer.setRepeats(false);
                timer.start();
            }
        });
    }

}

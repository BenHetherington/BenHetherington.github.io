package client;

import common.Direction;
import common.network.*;
import view.player.*;

import java.io.*;

/**
 * The main client logic for Dungeon of Doom.
 *
 * @author  Ben Hetherington & University of Bath
 * @version 2.0
 * @release 06/04/2016
 */
public abstract class ClientLogic {

    protected EventHandler eventHandler;

    private byte viewRadius = 5;
    private byte playerAlertRadius = 7;

    protected ClientConnection connection;

    /**
     * Establishes a connection to the given server.
     *
     * @param address
     *      The address of the server to connect to.
     * @param port
     *      The port of the server to connect to.
     * @throws IOException
     *      Thrown if there is a connection error.
     */
    public void connect(String address, int port) throws IOException {
        connection = new ClientConnection(this, address, port);
    }

    /**
     * Sends a move command to the server.
     *
     * @param direction
     *      The direction to move in.
     * @return
     *      The response from the server.
     */
    public Result move(Direction direction) {
        Commands command = null;

        switch (direction) {
            case Up:
                command = Commands.MoveUp;
                break;

            case Down:
                command = Commands.MoveDown;
                break;

            case Left:
                command = Commands.MoveLeft;
                break;

            case Right:
                command = Commands.MoveRight;
                break;
        }

        return sendCommand(command);
    }

    /**
     * Sends a pickup command to the server.
     *
     * @return
     *      The response from the server.
     */
    public Result pickup() {
        return sendCommand(Commands.Pickup);
    }

    /**
     * Sends a change sprite command to the server.
     *
     * @param character
     *      The character to be used.
     * @param sprite
     *      The sprite to be used.
     * @return
     *      The response from the server.
     */
    public synchronized Result changeSprite(Characters character, Sprites sprite) {
        return sendCommand(Commands.ChangeSprite, character.ID, sprite.value);
    }

    /**
     * Sends the quit command, and then closes the connection.
     */
    public void quit() {
        sendCommand(Commands.Quit);

        try {
            connection.closeSocket();
        } catch (IOException e) {
            // Not a lot we can do about this
        }
    }

    /**
     * Sends a command to the server, with the given parameters
     *
     * @param command
     *      The command to send.
     * @param parameters
     *      The parameters to send with the command, if any.
     * @return
     *      The response from the server.
     */
    public Result sendCommand(Commands command, byte... parameters) {
        if (!isGameRunning()) {
            return Result.Fail;
        }

        connection.sendCommand(command.value);

        for (byte parameter : parameters) {
            connection.sendCommand(parameter);
        }

        if (command == Commands.Quit) {
            return null;

        } else {
            return Result.valueOf(connection.getByte());
        }
    }

    /**
     * Handles the game finishing.
     *
     * @param winningPlayer
     *      The player ID of the player that won.
     */
    public abstract void finishGame(byte winningPlayer);

    /**
     * @return
     *      This client's player ID.
     */
    public byte getPlayerID() {
        return connection.playerID;
    }

    /**
     * Returns if the game is still running. PlayGame relies on this to decide if the main loop should be left.
     *
     * @return
     *      'true' if the game is running, otherwise 'false'.
     */
    public boolean isGameRunning() {
        return connection.isSocketOpen();
    }

    public void handleEvent(Events event) throws IOException, IllegalArgumentException {
        eventHandler.handleEvent(event);
    }

    /**
     * @return
     *      The current view radius.
     */
    public byte getViewRadius() {
        return viewRadius;
    }

    /**
     * Sets the view radius.
     *
     * @param viewRadius
     *      The new view radius.
     */
    public void setViewRadius(byte viewRadius) {
        this.viewRadius = viewRadius;
    }

    /**
     * @return
     *      The current player alert radius.
     */
    public byte getPlayerAlertRadius() {
        return playerAlertRadius;
    }

    /**
     * Sets the player alert radius.
     *
     * @param playerAlertRadius
     *      The new player alert radius.
     */
    public void setPlayerAlertRadius(byte playerAlertRadius) {
        this.playerAlertRadius = playerAlertRadius;
    }

    /**
     * Handles a communication error.
     *
     * @param cause
     *      The exception that was the cause of the error.
     */
    public abstract void handleCommunicationError(Exception cause);

}

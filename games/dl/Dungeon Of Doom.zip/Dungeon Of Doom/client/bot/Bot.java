package client.bot;

import client.*;
import common.network.*;
import view.player.Characters;
import view.player.Sprites;

import java.io.IOException;
import java.util.*;

/**
 * An AI-based Bot that finds gold on the map, and then navigates to the exit.
 * When run, plays the dungeon hosted by a server.
 *
 * @author  Ben Hetherington & University of Bath
 * @version 1.2
 * @see     BotMap
 * @see     BotAI
 * @release 06/04/2016
 */
public class Bot extends ClientLogic {

    private static final boolean DEBUGGING_MESSAGES_ENABLED = false;

    private Random random = new Random();
    private BotAI botAI = new BotAI();

    public Bot() {
        eventHandler = new BotEventHandler(this);
    }

    /**
     * The main loop for the bot. Decides the bot's next move, and sends it to the server.
     */
    public void run() {
        Result answer = null;

        while (isGameRunning()) {
            try {
                Thread.sleep(500 + random.nextInt(2500));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            Commands command = botAI.decideNextMove(answer);
            answer = sendCommand(command);

            if (isGameRunning() && command != Commands.Pickup) {
                botAI.updateMap(answer == Result.Success);
                changeSprite(Characters.Bot, Sprites.getSprite(botAI.getDirection(), true));

                final Timer spriteChangeTimer = new Timer("Bot Sprite Timer");
                spriteChangeTimer.schedule(new TimerTask() {
                    public void run() {
                        changeSprite(Characters.Bot, Sprites.getSprite(botAI.getDirection(), false));
                        spriteChangeTimer.purge();
                    }
                }, 250);
            }

            if (DEBUGGING_MESSAGES_ENABLED && answer != null) {
                System.out.println(answer);
            }
        }
    }

    /**
     * Handles the game finishing.
     *
     * @param winningPlayer
     *      The player ID of the winning player
     */
    public void finishGame(byte winningPlayer) {
        try {
            connection.closeSocket();
        } catch (IOException e) {
            // Not a lot we can do about that
        }
    }

    /**
     * Handles communication errors.
     *
     * @param cause
     *      The thrown exception, if known.
     */
    public void handleCommunicationError(Exception cause) {
        // Swallows the error, since the user will likely see one too for their player's connection.
        try {
            connection.closeSocket();
        } catch (IOException e) {
            // Not a lot we can do about that
        }
    }

    /**
     * Handles an event.
     *
     * @param event
     *      The event to be handled.
     * @throws IOException
     *      Thrown if there is a communication error.
     * @throws IllegalArgumentException
     *      Thrown if the event parameters are invalid.
     */
    public void handleEvent(Events event) throws IOException, IllegalArgumentException {
        eventHandler.handleEvent(event);
    }

    /**
     * @return
     *      The bot AI.
     */
    public BotAI getBotAI() {
        return botAI;
    }

}

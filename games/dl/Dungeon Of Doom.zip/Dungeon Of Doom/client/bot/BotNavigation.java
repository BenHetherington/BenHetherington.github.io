package client.bot;

import common.Direction;

import java.awt.Point;
import java.util.*;

/**
 * Encapsulates the methods for route planning, including the A* search algorithm.
 *
 * The A* search algorithm is based on the pseudocode from Wikipedia.
 * (Can be found at: https://en.wikipedia.org/wiki/A*_search_algorithm#Pseudocode)
 *
 * @author  Ben Hetherington
 * @version 1.1
 * @release 06/04/2016
 */
class BotNavigation {

    /**
     * This method will use a search algorithm to get from the relativePosition in the map to the destination.
     *
     * @param map
     *      The map to navigate
     * @param destination
     *      The destination tile to reach
     * @return
     *      The sequence of moves to execute, or null if this is not possible
     */
    public static Queue<Direction> planRoute(BotMap map, Point destination) {
        return aStarSearch(map, destination);
    }

    /**
     * An implementation of the A* algorithm.
     * Based on the pseudocode from Wikipedia. (https://en.wikipedia.org/wiki/A*_search_algorithm#Pseudocode)
     *
     * @param destination
     *      The desired destination
     */
    private static Queue<Direction> aStarSearch(BotMap map, Point destination) {
        Point start = new Point(map.getRelativePosition());

        HashSet<Point> closedSet = new HashSet<>();
        HashSet<Point> openSet = new HashSet<>();
        HashMap<Point, Point> cameFrom = new HashMap<>();

        HashMap<Point, Integer> gScore = new HashMap<>();
        HashMap<Point, Integer> fScore = new HashMap<>();

        openSet.add(start);
        gScore.put(start, 0);
        fScore.put(start, calculateDistance(start, destination));

        while (openSet.size() > 0) {
            Point current = null;
            int lowestFScoreValue = Integer.MAX_VALUE;

            for (Point pointToTest : openSet) {
                if (fScore.get(pointToTest) <= lowestFScoreValue) {
                    current = pointToTest;
                }
            }

            if (current.equals(destination)) {
                return reconstructRoute(cameFrom, destination);
            }

            openSet.remove(current);
            closedSet.add(current);

            ArrayList<Point> neighbours = new ArrayList<>();

            Point[] potentialNeighbours = {new Point(current.x - 1, current.y), new Point(current.x, current.y - 1),
                    new Point(current.x + 1, current.y), new Point(current.x, current.y + 1)};

            for (Point potentialNeighbour : potentialNeighbours) {
                if (!map.checkCollision(potentialNeighbour)) {
                    neighbours.add(potentialNeighbour);
                }
            }

            for (Point neighbour : neighbours) {
                if (closedSet.contains(neighbour)) {
                    continue; // Ignore the already-evaluated neighbour
                }

                // The distance from start to goal passing through current and the neighbor.
                int tentativeGScore = gScore.get(current) + 1;

                if (!openSet.contains(neighbour)) {
                    openSet.add(neighbour);
                    fScore.put(neighbour, Integer.MAX_VALUE);
                } else if (tentativeGScore >= gScore.get(neighbour)) {
                    continue; // This is not a better path
                }

                // This is the best path until now.
                cameFrom.put(neighbour, current);
                gScore.put(neighbour, tentativeGScore);
                fScore.put(neighbour, tentativeGScore + calculateDistance(neighbour, destination));
            }
        }

        return null; // Can't find any route to this point.
    }

    /**
     * Constructs an array containing all of the points between the destination and the start.
     *
     * @param cameFrom
     *      The map of all the points
     * @param current
     *      The current point
     * @return
     *      The constructed array
     */
    private static ArrayList<Point> reconstructPath(HashMap<Point, Point> cameFrom, Point current) {
        ArrayList<Point> totalPath = new ArrayList<>();
        totalPath.add(current);
        while (cameFrom.containsKey(current)) {
            current = cameFrom.get(current);
            totalPath.add(current);
        }
        return totalPath;
    }

    /**
     * Constructs the route, returning the needed directions to travel.
     *
     * @param cameFrom
     *      The map of all the points
     * @param current
     *      The current point
     * @return
     *      The constructed route
     */
    private static Queue<Direction> reconstructRoute(HashMap<Point, Point> cameFrom, Point current) {
        ArrayList<Point> path = reconstructPath(cameFrom, current);
        Queue<Direction> route = new ArrayDeque<>();

        for (int i = path.size() - 2; i >= 0; i--) {
            Point from = path.get(i + 1);
            Point to = path.get(i);

            if (to.x > from.x) {
                route.add(Direction.Right);
            } else if (to.x < from.x) {
                route.add(Direction.Left);
            } else if (to.y > from.y) {
                route.add(Direction.Down);
            } else if (to.y < from.y) {
                route.add(Direction.Up);
            } else {
                throw new RuntimeException("Error reconstructing the route.");
            }
        }

        return route;
    }

    /**
     * Calculates the distance between two points, without diagonals.
     *
     * @param point1
     *      The first point to be used in the calculation
     * @param point2
     *      The second point to be used in the calculation
     * @return
     *      The distance between the two points
     */
    private static int calculateDistance(Point point1, Point point2) {
        return Math.abs(point1.x - point2.x) + Math.abs(point1.y - point2.y);
    }

}

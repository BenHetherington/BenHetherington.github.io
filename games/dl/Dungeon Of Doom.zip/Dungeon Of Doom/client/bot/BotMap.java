package client.bot;

import common.*;
import common.array.*;

import java.awt.*;
import java.util.*;
import java.util.concurrent.CountDownLatch;

/**
 * The bot's known map. Enables it to remember where the exits are, and to travel to them quickly.
 *
 * @author  Ben Hetherington
 * @version 1.1
 * @see     Bot
 * @release 06/04/2016
 */
public class BotMap {

    private ArrayList2D<Tile> map = new ArrayList2D<>();              // The map that's been seen by the bot
    private Point relativePosition = null;                            // The position relative to the known map
    private Map<Byte, Point> playerPositions = new HashMap<>();       // The positions of nearby players
    private CountDownLatch allowUpdatesLatch = new CountDownLatch(0); // A latch, allowing updates to be paused.

    private int viewRadius = 0;
    private int playerAlertRadius = 0;

    /**
     * @return
     *      The current position of the player relative to the known map
     */
    public Point getRelativePosition() {
        return relativePosition;
    }

    /**
     * @return
     *      An ArrayList of ArrayList (2D array) containing the map tiles.
     */
    public ArrayList2D<Tile> getMap() {
        return map;
    }

    /**
     * @return
     *      The number of tiles the map has vertically.
     */
    public int getHeight() {
        return map.getHeight();
    }

    /**
     * @return
     *      The number of tiles the map has horizontally.
     */
    public int getWidth() {
        return map.getWidth();
    }

    /**
     * Blocks the current thread until the map is allowed to be updated.
     */
    private void waitUntilUpdatesAreAllowed() {
        try {
            allowUpdatesLatch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Update the entire map in the look radius.
     *
     * @param tiles
     *      The tiles in the visible area.
     */
    public void updateEntireVisibleMap(Tile[][] tiles) {
        waitUntilUpdatesAreAllowed();

        ensureMapIsSetUp();
        ensureSpaceForNewTiles();

        Point offset = new Point(relativePosition.x - viewRadius / 2, relativePosition.y - viewRadius / 2);
        for (int i = 0; i < viewRadius; i++) {
            for (int j = 0; j < viewRadius; j++) {
                map.set(j + offset.x, i + offset.y, tiles[i][j]);
            }
        }
    }

    /**
     * Updates the given column within the visible area.
     *
     * @param xInView
     *      The x coordinate of the column within the visible area.
     * @param tiles
     *      The tiles to be placed in the new column.
     */
    public void updateColumn(int xInView, Tile[] tiles) {
        waitUntilUpdatesAreAllowed();

        ensureMapIsSetUp();
        ensureSpaceForNewTiles();

        Point offset = new Point(relativePosition.x + xInView - viewRadius / 2, relativePosition.y - viewRadius / 2);
        for (int i = 0; i < viewRadius; i++) {
            map.set(offset.x, i + offset.y, tiles[i]);
        }
    }

    /**
     * Updates the given row within the visible area.
     *
     * @param yInView
     *      The y coordinate of the row within the visible area.
     * @param tiles
     *      The tiles to be placed in the new row.
     */
    public void updateRow(int yInView, Tile[] tiles) {
        waitUntilUpdatesAreAllowed();

        ensureMapIsSetUp();
        ensureSpaceForNewTiles();

        Point offset = new Point(relativePosition.x - viewRadius / 2, relativePosition.y + yInView - viewRadius / 2);
        for (int i = 0; i < viewRadius; i++) {
            map.set(i + offset.x, offset.y, tiles[i]);
        }
    }

    /**
     * Updates a single tile within the visible area.
     *
     * @param positionInView
     *      The position of the tile relative to the visible area.
     * @param tile
     *      The tile to be updated.
     */
    public void updateTile(Point positionInView, Tile tile) {
        waitUntilUpdatesAreAllowed();

        Point offset = new Point(relativePosition.x + positionInView.x - viewRadius / 2,
                relativePosition.y + positionInView.y - viewRadius / 2);
        map.set(offset.x, offset.y, tile);
    }

    /**
     * Enables or disables the map from being updated. If disabled, subsequent attempts
     * to modify the map will cause the thread to be blocked, until updates are re-enabled.
     *
     * @param allowUpdates
     *      True if the map should be modifiable, false otherwise.
     */
    public void setAllowUpdates(boolean allowUpdates) {
        if (allowUpdates) {
            allowUpdatesLatch.countDown();

        } else {
            if (allowUpdatesLatch.getCount() <= 0) {
                allowUpdatesLatch = new CountDownLatch(1);
            }
        }
    }

    /**
     * Updates the player's position within the known map.
     *
     * @param direction
     *      The direction moved.
     */
    public void updatePosition(Direction direction) {
        if (direction != null) {
            switch (direction) {
                case Right:
                    relativePosition.x++;
                    break;

                case Left:
                    relativePosition.x--;
                    break;

                case Down:
                    relativePosition.y++;
                    break;

                case Up:
                    relativePosition.y--;
                    break;
            }
        }
    }

    /**
     * Ensures that the map has been initialised, and places the player in the centre of the map if not.
     */
    private void ensureMapIsSetUp() {
        if (map.getHeight() == 0) {
            relativePosition = new Point(viewRadius / 2, viewRadius / 2);
            map.ensureDimensions(viewRadius, viewRadius);
        }
    }

    /**
     * Ensures that there is space in the map array for new tiles.
     */
    private void ensureSpaceForNewTiles() {
        if (relativePosition.x - viewRadius / 2 < 0) {
            map.addColumn(HorizontalPosition.Left);
            relativePosition.x++;

            for (Point point : playerPositions.values()) {
                point.x++;
            }

        } else if (relativePosition.x + viewRadius / 2 >= map.getWidth()) {
            map.addColumn(HorizontalPosition.Right);

        } else if (relativePosition.y - viewRadius / 2 < 0) {
            map.addRow(VerticalPosition.Top);
            relativePosition.y++;

            for (Point point : playerPositions.values()) {
                point.y++;
            }

        } else if (relativePosition.y + viewRadius / 2 >= map.getHeight()) {
            map.addRow(VerticalPosition.Bottom);
        }
    }

    /**
     * Works out if there will be collision at the specified position.
     * A collision would occur if the tile is a wall.
     * If the bot is currently in the LOOK radius, this method will also check for collisions with other players.
     *
     * @param position
     *      The position to check
     * @return
     *      True if there would be a collision
     */
    public boolean checkCollision(Point position) {
        if (position.y >= map.getHeight() || position.x >= map.getWidth() || position.y < 0 || position.x < 0) {
            return true;
        }

        Tile tile = map.get(position.x, position.y);
        return tile == Tile.Wall || playerPositions.values().contains(position);
    }

    /**
     * Returns the map's ASCII representation. For debugging purposes only.
     *
     * @return
     *      The map's ASCII representation.
     */
    public String toString() {
        StringBuilder returnString = new StringBuilder();

        for (int i = 0; i < map.getHeight(); i++) {
            for (int j = 0; j < map.getWidth(); j++) {
                Tile tile = map.get(j, i);
                if (tile != null) {
                    returnString.append(tile.charValue);
                } else {
                    returnString.append('X');
                }
                returnString.append(' ');
            }
            returnString.append('\n');
        }

        return returnString.toString();
    }

    /**
     * Searches for a desired tile type on the map, and returns the positions of
     * all found occurrences of that tile type.
     *
     * @param tileToFind
     *      The type of tile to be found
     * @return
     *      The positions where this tile can be found.
     */
    public ArrayList<Point> findTile(Tile tileToFind) {
        ArrayList<Point> result = new ArrayList<>();

        for (int i = 0; i < map.getHeight(); i++) {
            for (int j = 0; j < map.getWidth(); j++) {
                if (map.get(j, i) == tileToFind) {
                    result.add(new Point(j, i));
                }
            }
        }

        return result;
    }

    /**
     * Updates the known position of a given player.
     *
     * @param playerID
     *      The player whose position is to be updated.
     * @param position
     *      The new position, relative to the player alert radius
     */
    public void updatePlayerPositions(byte playerID, Point position) {
        if (position != null) {
            ensureMapIsSetUp();
            Point offset = new Point(relativePosition.x - playerAlertRadius / 2, relativePosition.y - playerAlertRadius / 2);
            playerPositions.put(playerID, new Point(offset.x + position.x, offset.y + position.y));

        } else {
            playerPositions.remove(playerID);
        }
    }

    /**
     * Sets the view radius.
     *
     * @param viewRadius
     *      The new view radius.
     */
    public void setViewRadius(int viewRadius) {
        this.viewRadius = viewRadius;
    }

    /**
     * Sets the player alert radius.
     *
     * @param playerAlertRadius
     *      The new player alert radius.
     */
    public void setPlayerAlertRadius(int playerAlertRadius) {
        this.playerAlertRadius = playerAlertRadius;
    }

}
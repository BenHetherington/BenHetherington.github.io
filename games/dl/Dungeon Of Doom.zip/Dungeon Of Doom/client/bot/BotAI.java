package client.bot;

import common.*;
import common.network.*;

import java.awt.Point;
import java.util.*;

/**
 * Encapsulates all of the decision-making for the bot.
 *
 * @author  Ben Hetherington
 * @version 1.1
 * @see     Bot
 * @see     BotNavigation
 * @release 06/04/2016
 */
class BotAI {

    private static final boolean DEBUGGING_MESSAGES_ENABLED = false;

    private Random random = new Random();
    private Tile destination = Tile.Gold;                    // The tile that the bot is trying to find.
    private BotMap map = new BotMap();                       // The map that's been seen by the bot
    private Direction direction = null;                      // The direction of the last successful MOVE command
    private Point nextTarget = null;                         // The next point to aim for; ideally a destination
    private Queue<Direction> nextMoves = new ArrayDeque<>(); // The next moves to execute
    private MovementType movementType = MovementType.Random; // The current type of movement
    private Commands lastCommand = null;                     // The last command to be sent by the bot.

    /**
     * Parses the last response from the server, and decides what to do next.
     *
     * @param lastResponse
     *      The previous response from the server.
     * @return
     *      The next command to send.
     */
    private Commands decideNextCommand(Result lastResponse) {
        if (lastCommand == null) {
            // First command
            return move();
        }

        switch (lastCommand) {
            case MoveUp:
            case MoveDown:
            case MoveLeft:
            case MoveRight:
                return respondToMoveCommand(lastResponse);

            case Pickup:
                return respondToPickupCommand(lastResponse);

            default:
                throw new AssertionError("An unknown command '" + lastCommand + "' was issued, and cannot be processed.");
        }
    }

    /**
     * Parses the last response from the server, and stores the next command to be sent.
     *
     * @param lastResponse
     *      The previous response from the server.
     * @return
     *      The next command to send.
     */
    public Commands decideNextMove(Result lastResponse) {
        lastCommand = decideNextCommand(lastResponse);
        return lastCommand;
    }

    /**
     * Parses a change in the gold count, and modifies the bot's destination to suit.
     *
     * @param collectedGold
     *      The amount of gold on hand.
     * @param neededGold
     *      The amount of gold needed to exit the dungeon.
     */
    public void parseGoldUpdate(byte collectedGold, byte neededGold) {
        if (collectedGold >= neededGold) {
            destination = Tile.Exit;
        } else {
            destination = Tile.Gold;
        }

        // Restart route planning
        nextMoves = new ArrayDeque<>();
        nextTarget = null;
    }

    /**
     * Parses the server's response when the bot last sent a move command.
     * Continues moving, planning the route if necessary, or picks up if the bot is on some gold.
     *
     * @param lastResponse
     *      The previous response from the server.
     * @return
     *      The next command to send.
     */
    private Commands respondToMoveCommand(Result lastResponse) {
        if (lastResponse == Result.Fail) {
            nextMoves.clear();
            direction = null;
        }

        if (map.getMap().get(map.getRelativePosition().x, map.getRelativePosition().y) == Tile.Gold) {
            return Commands.Pickup;
        }

        return move();
    }

    /**
     * Updates the bot's map, and re-enables updates for it.
     *
     * @param success
     *      True if the last move was successful.
     */
    public void updateMap(boolean success) {
        if (success) {
            map.updatePosition(direction);
        }
        map.setAllowUpdates(true);
    }

    /**
     * Parses the server's response when the bot last sent a pickup command.
     * Continues moving, planning the route if necessary.
     *
     * @param lastResponse
     *      The last response from the server.
     * @return
     *      The next command to send. Will always be a move command.
     */
    private Commands respondToPickupCommand(Result lastResponse) {
        if (lastResponse == Result.Fail) {
            direction = null;
        }

        return move();
    }

    /**
     * Decides on the next movement.
     *
     * @return
     *      The next command to send. Will always be a move command.
     */
    private Commands move() {
        if (nextTarget == null || nextMoves.size() == 0) {
            nextTarget = null;
            replanRoute();
        }

        if (nextMoves != null && nextMoves.size() > 0) {
            direction = nextMoves.poll();

        } else {
            // A last resort, if no sensible move can be made
            movementType = MovementType.Random;
            nextMoves = new ArrayDeque<>();
            direction = Direction.values()[random.nextInt(Direction.values().length)];
        }

        if (DEBUGGING_MESSAGES_ENABLED) {
            System.out.print(movementType + " - ");
            if (nextTarget != null) {
                System.out.println("(" + map.getRelativePosition().x + ", " + map.getRelativePosition().y +
                        ") to (" + nextTarget.x + ", " + nextTarget.y + ")");
            }
            if (nextMoves != null) {
                System.out.println(direction + " " + nextMoves);
            }
            System.out.println();
        }

        map.setAllowUpdates(false);

        switch (direction) {
            case Up:
                return Commands.MoveUp;

            case Down:
                return Commands.MoveDown;

            case Left:
                return Commands.MoveLeft;

            case Right:
                return Commands.MoveRight;

            default:
                // This shouldn't be reached
                throw new AssertionError("Failed to find a direction to move in.");
        }
    }

    /**
     * Re-plans the route.
     * If it can see its destination tile, then it'll travel towards it.
     * Otherwise, it'll try to explore unexplored areas of the map.
     */
    private void replanRoute() {
        ArrayList<Point> potentialTargets = map.findTile(destination);

        if (potentialTargets != null && potentialTargets.size() > 0) {
            // Try to plan the route to this target
            selectNextTarget(potentialTargets);
        }

        if (nextTarget == null) {
            // If the target is inaccessible, or can't be found, explore instead
            startExploring();
        }
    }

    /**
     * Selects the target with the shortest route, and saves the route.
     *
     * @param potentialTargets
     *      The possible targets to pick from.
     */
    private void selectNextTarget(ArrayList<Point> potentialTargets) {
        int shortestDistance = Integer.MAX_VALUE;

        for (Point target : potentialTargets) {
            Queue<Direction> moves = BotNavigation.planRoute(map, target);

            if (moves != null && moves.size() <= shortestDistance) {
                shortestDistance = moves.size();
                nextTarget = target;
                nextMoves = moves;
                movementType = MovementType.Targeting;
            }
        }
    }

    /**
     * Picks the closest unexplored area of the map, and saves the route.
     */
    private void startExploring() {
        movementType = MovementType.Exploring;

        ArrayList<Point> possibleTargets = new ArrayList<>();
        int shortestRoute = Integer.MAX_VALUE;

        possibleTargets.addAll(map.findTile(null));
        possibleTargets.addAll(getPointsOnEdge(map));

        for (Point possibleTarget : possibleTargets) {
            Queue<Direction> route = BotNavigation.planRoute(map, possibleTarget);

            if (route != null) {
                if (route.size() < shortestRoute || (route.size() == shortestRoute && random.nextBoolean())) {
                    nextTarget = possibleTarget;
                    nextMoves = route;
                    shortestRoute = route.size();
                }
            }
        }
    }

    /**
     * Returns the positions of the tiles on the edge of the map.
     * @param map
     *      The map with the desired dimensions.
     * @return
     *      The positions of the tiles on the edge of the map.
     */
    private ArrayList<Point> getPointsOnEdge(BotMap map) {
        ArrayList<Point> pointsToReturn = new ArrayList<>();

        for (int i = 0; i < map.getWidth(); i++) {
            pointsToReturn.add(new Point(i, 0));
            pointsToReturn.add(new Point(i, map.getHeight() - 1));
        }

        for (int j = 1; j < map.getHeight() - 1; j++) {
            pointsToReturn.add(new Point(0, j));
            pointsToReturn.add(new Point(map.getWidth() - 1, j));
        }

        return pointsToReturn;
    }

    /**
     * Updates the entire map. Used to handle EntireMapUpdate events.
     *
     * @param tiles
     *      The visible tiles.
     */
    public void updateEntireVisibleMap(Tile[][] tiles) {
        map.updateEntireVisibleMap(tiles);
        printMapIfNeeded();
    }

    /**
     * Updates the column in the player's view. Used to handle MapColumnUpdate events.
     *
     * @param xInView
     *      The x-coordinate of this column, relative to the player's view.
     * @param tiles
     *      The tiles in this column.
     */
    public void updateColumn(int xInView, Tile[] tiles) {
        map.updateColumn(xInView, tiles);
        printMapIfNeeded();
    }

    /**
     * Updates the row in the player's view. Used to handle MapRowUpdate events.
     *
     * @param yInView
     *      The y-coordinate of this row, relative to the player's view.
     * @param tiles
     *      The tiles in this column.
     */
    public void updateRow(int yInView, Tile[] tiles) {
        map.updateRow(yInView, tiles);
        printMapIfNeeded();
    }

    /**
     * Updates the tile at the given position, relative to the player's view.
     * Used to handle TileChanged events.
     *
     * @param positionInView
     *      The position of the tile, relative to the player's view.
     * @param tile
     *      The new tile.
     */
    public void updateTile(Point positionInView, Tile tile) {
        map.updateTile(positionInView, tile);
        printMapIfNeeded();
    }

    /**
     * Used to print the map after one of the map event handlers is called, and debugging messages are enabled.
     * For debugging purposes only.
     */
    private void printMapIfNeeded() {
        if (DEBUGGING_MESSAGES_ENABLED) {
            System.out.println(map);
        }
    }

    /**
     * Updates the given player's position. Used to handle PlayerMoved and PlayerOutOfView events.
     *
     * @param playerID
     *      The ID of the player whose position is to be modified.
     * @param position
     *      The position of the player, relative to the player alert radius.
     */
    public void updatePlayerPositions(byte playerID, Point position) {
        map.updatePlayerPositions(playerID, position);
    }

    /**
     * Sets the view radius. Used to handle ViewRadiusChanged events.
     *
     * @param viewRadius
     *      The new view radius.
     */
    public void setViewRadius(byte viewRadius) {
        map.setViewRadius(viewRadius);
    }

    /**
     * Sets the player alert radius. Used to handle PlayerAlertRadius events.
     *
     * @param playerAlertRadius
     *      The new player alert radius.
     */
    public void setPlayerAlertRadius(byte playerAlertRadius) {
        map.setPlayerAlertRadius(playerAlertRadius);
    }

    /**
     * @return
     *      The bot's last movement direction.
     */
    protected Direction getDirection() {
        return direction;
    }

}

enum MovementType {
    Targeting, Exploring, Random
}

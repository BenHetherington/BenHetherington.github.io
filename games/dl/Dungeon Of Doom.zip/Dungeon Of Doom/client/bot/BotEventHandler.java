package client.bot;

import client.*;
import common.Tile;
import view.player.Characters;
import view.player.Sprites;

import java.awt.*;

/**
 * The bot's event handler. Makes the bot aware of events sent by the server.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
class BotEventHandler extends EventHandler {

    private Bot bot;

    /**
     * Constructs a new BotEventHandler.
     *
     * @param bot
     *      The Bot to associate with this BotEventHandler.
     */
    public BotEventHandler(Bot bot) {
        super(bot);
        this.bot = bot;
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerMoved(byte playerID, byte positionX, byte positionY) {
        bot.getBotAI().updatePlayerPositions(playerID, new Point(positionX, positionY));
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerOutOfView(byte playerID) {
        bot.getBotAI().updatePlayerPositions(playerID, null);
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerSpriteChanged(byte playerID, Characters character, Sprites sprite) {
        // The bot will simply ignore this event.
    }

    /**
     * {@inheritDoc}
     */
    protected void handleTileChanged(byte positionX, byte positionY, Tile newTile) {
        bot.getBotAI().updateTile(new Point(positionX, positionY), newTile);
    }

    /**
     * {@inheritDoc}
     */
    protected void handleGoldChanged(byte collectedGold, byte neededGold) {
        bot.getBotAI().parseGoldUpdate(collectedGold, neededGold);
    }

    /**
     * {@inheritDoc}
     */
    protected void handleEntireMapUpdate(Tile[][] newMap) {
        bot.getBotAI().updateEntireVisibleMap(newMap);
    }

    /**
     * {@inheritDoc}
     */
    protected void handleMapRowUpdate(byte positionY, Tile[] newRow) {
        bot.getBotAI().updateRow(positionY, newRow);
    }

    /**
     * {@inheritDoc}
     */
    protected void handleMapColumnUpdate(byte positionX, Tile[] newColumn) {
        bot.getBotAI().updateColumn(positionX, newColumn);
    }

    /**
     * {@inheritDoc}
     */
    protected void handleViewRadiusChanged(byte newViewRadius) {
        super.handleViewRadiusChanged(newViewRadius);
        bot.getBotAI().setViewRadius(newViewRadius);
    }

    /**
     * {@inheritDoc}
     */
    protected void handlePlayerAlertRadiusChanged(byte newPlayerAlertRadius) {
        super.handlePlayerAlertRadiusChanged(newPlayerAlertRadius);
        bot.getBotAI().setPlayerAlertRadius(newPlayerAlertRadius);
    }

    /**
     * {@inheritDoc}
     */
    protected void handleGameFinished(byte winningPlayer) {
        bot.finishGame(winningPlayer);
    }

}

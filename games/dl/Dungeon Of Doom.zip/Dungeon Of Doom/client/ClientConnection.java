package client;

import common.network.Events;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Manages the client's connection to the server.
 *
 * @author  Ben Hetherington
 * @version 2.0
 * @release 06/04/2016
 */
public class ClientConnection {

    private ClientLogic clientLogic;
    final private Queue<Byte> inputBuffer = new ArrayDeque<>();
    private CountDownLatch latch;
    final public byte playerID;

    private Socket socket;
    private InputStream input;
    private OutputStream output;

    /**
     * Creates a new ClientConnection, and connects to the server at the given address and port.
     *
     * @param address
     *      The address of the server to connect to.
     * @param port
     *      The port of the server to connect to.
     * @throws IOException
     *      Thrown if a connection couldn't be established.
     */
    public ClientConnection(ClientLogic clientLogic, String address, int port) throws IOException {
        this.clientLogic = clientLogic;
        socket = new Socket(address, port);
        input = socket.getInputStream();
        output = socket.getOutputStream();

        playerID = getEventByte();

        Thread processInputThread = new Thread(new Runnable() {
            public void run() {
                processInputLoop();
            }
        });
        processInputThread.setName("ClientConnection: Process Input Loop");
        processInputThread.start();

        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                if (!socket.isClosed()) {
                    try {
                        socket.close();

                    } catch (IOException e) {
                        // Not a lot we can do about that at this point
                    }
                }
            }
        });
    }

    /**
     * @return
     *      True if the socket hasn't yet been closed.
     */
    public boolean isSocketOpen() {
        return !socket.isClosed();
    }

    /**
     * Closes the socket.
     *
     * @throws IOException
     *      Thrown if the socket couldn't be closed.
     */
    public void closeSocket() throws IOException {
        socket.close();
    }

    /**
     * This method will continually read new data as it comes from the server.
     * If an event is received, then it's handled. Otherwise, the byte is stashed in a buffer.
     */
    private void processInputLoop() {
        try {
            latch = new CountDownLatch(1);

            while (!socket.isClosed()) {
                int result = input.read();

                if (result == -1) {
                    throw new EOFException();

                } else if (Events.valueOf((byte)result) != null) {
                    clientLogic.handleEvent(Events.valueOf((byte)result));

                } else {
                    // Stash it in the buffer
                    synchronized (inputBuffer) {
                        inputBuffer.add((byte)result);
                    }
                    latch.countDown();
                    latch = new CountDownLatch(1);
                }
            }

        } catch (IOException | IllegalArgumentException e) {
            latch.countDown();
            clientLogic.handleCommunicationError(e);
            try {
                closeSocket();
            } catch (IOException e1) {
                // Not a lot we can do about that
            }
        }
    }

    /**
     * Sends a command to the server.
     *
     * @param command
     *      The command to be sent.
     */
    public void sendCommand(byte command) {
        try {
            output.write(command);

        } catch (IOException e) {
            latch.countDown();
            clientLogic.handleCommunicationError(e);
            try {
                closeSocket();
            } catch (IOException e1) {
                // Not a lot we can do about that
            }
        }
    }

    /**
     * Retrieves a byte from the server. Must only be called to get event parameters.
     *
     * @return
     *      The byte received.
     * @throws IOException
     *      Thrown if there is a communication error.
     */
    public byte getEventByte() throws IOException {
        int result = input.read();
        if (result != -1) {
            return (byte)result;

        } else {
            throw new EOFException();
        }
    }

    /**
     * Gets the next byte from the server.
     * Waits until the buffer has at least one byte in it, and then returns the next byte from the buffer.
     * @return
     *      The next byte to be processed.
     */
    public synchronized byte getByte() {
        for (;;) {
            CountDownLatch latch = this.latch;

            synchronized (inputBuffer) {
                if (inputBuffer.size() > 0) {
                    return inputBuffer.poll();
                }
            }

            try {
                latch.await();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

}

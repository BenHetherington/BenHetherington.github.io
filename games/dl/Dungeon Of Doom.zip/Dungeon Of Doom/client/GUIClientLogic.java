package client;

import controller.ViewController;

import java.io.IOException;

/**
 * Handles the client logic, while a GUI is being used.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class GUIClientLogic extends ClientLogic {

    private ViewController viewController;

    /**
     * Constructs a new GUIClientLogic object with the given view controller.
     *
     * @param viewController
     *      The view controller to associate with the game logic.
     */
    public GUIClientLogic(ViewController viewController) {
        this.viewController = viewController;
        eventHandler = new GUIEventHandler(this, viewController);
    }

    /**
     * Handles the game finishing, by closing the connection.
     *
     * @param winningPlayer
     *      The player ID of the winning player.
     */
    public void finishGame(byte winningPlayer) {
        try {
            connection.closeSocket();
        } catch (IOException e) {
            // Not a lot we can do about that now
        }
    }

    /**
     * Handles a communication error.
     *
     * @param cause
     *      The exception that caused the error.
     */
    public void handleCommunicationError(Exception cause) {
        if (isGameRunning()) {
            viewController.handleCommunicationError(cause);
        }
    }
}

package client;

import common.Tile;
import common.network.Events;
import view.player.Characters;
import view.player.Sprites;

import java.io.IOException;

/**
 * Processes events, and passes them on for them to be handled.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public abstract class EventHandler {

    protected ClientLogic logic;

    /**
     * Constructs a new EventHandler.
     * The given logic object will be used for storing and retrieving the view radius and the player alert radius,
     * and its connection will be used to get event parameters.
     * It may also be used by subclasses, in order to handle events.
     *
     * @param logic
     *      The logic object to associate with this event handler.
     */
    public EventHandler(ClientLogic logic) {
        this.logic = logic;
    }

    /**
     * Handles and processes the given event.
     *
     * @param event
     *      The event to be handled.
     */
    final public void handleEvent(Events event) throws IOException, IllegalArgumentException {
        switch (event) {
            case PlayerMoved:
                processPlayerMoved();
                break;

            case PlayerOutOfView:
                processPlayerOutOfView();
                break;

            case PlayerSpriteChanged:
                processPlayerSpriteChanged();
                break;

            case TileChanged:
                processTileChanged();
                break;

            case GoldChanged:
                processGoldChanged();
                break;

            case EntireMapUpdate:
                processEntireMapUpdate();
                break;

            case MapRowUpdate:
                processMapRowUpdate();
                break;

            case MapColumnUpdate:
                processMapColumnUpdate();
                break;

            case ViewRadiusChanged:
                processViewRadiusChanged();
                break;

            case PlayerAlertRadiusChanged:
                processPlayerAlertRadiusChanged();
                break;

            case GameFinished:
                processGameFinished();
                break;

            default:
                throw new AssertionError("The '" + event + "' event handler has not been implemented.");
        }
    }

    /**
     * Gets the parameters of a PlayerMoved event, and passes them onto the handler.
     * These parameters are validated in the process.
     */
    private void processPlayerMoved() throws IOException, IllegalArgumentException {
        byte playerID = logic.connection.getEventByte();
        byte positionX = logic.connection.getEventByte();
        byte positionY = logic.connection.getEventByte();

        validateNonNegativeValue(playerID);
        validatePosition(positionX, positionY);

        handlePlayerMoved(playerID, positionX, positionY);
    }

    /**
     * Gets the parameter of a PlayerOutOfView event, and passes it onto the handler.
     * This parameter is validated in the process.
     */
    private void processPlayerOutOfView() throws IOException, IllegalArgumentException {
        byte playerID = logic.connection.getEventByte();
        validateNonNegativeValue(playerID);
        handlePlayerOutOfView(playerID);
    }

    /**
     * Gets the parameter of a PlayerSpriteChanged event, and passes it onto the handler.
     * This parameter is validated in the process.
     */
    private void processPlayerSpriteChanged() throws IOException, IllegalArgumentException {
        byte playerID = logic.connection.getEventByte();
        byte characterID = logic.connection.getEventByte();
        byte spriteID = logic.connection.getEventByte();

        Characters character = Characters.valueOf(characterID);
        Sprites sprite = Sprites.valueOf(spriteID);

        validateNonNullObject(character);
        validateNonNullObject(sprite);

        handlePlayerSpriteChanged(playerID, character, sprite);
    }

    /**
     * Gets the parameters of a TileChanged event, and passes them onto the handler.
     * These parameters are validated in the process.
     */
    private void processTileChanged() throws IOException, IllegalArgumentException {
        byte positionX = logic.connection.getEventByte();
        byte positionY = logic.connection.getEventByte();
        byte newTile = logic.connection.getEventByte();

        validatePosition(positionX, positionY);
        validateNonNullObject(newTile);

        handleTileChanged(positionX, positionY, Tile.valueOf(newTile));
    }

    /**
     * Gets the parameters of a GoldChanged event, and passes them onto the handler.
     * These parameters are validated in the process.
     */
    private void processGoldChanged() throws IOException, IllegalArgumentException {
        byte collectedGold = logic.connection.getEventByte();
        byte neededGold = logic.connection.getEventByte();

        validateNonNegativeValue(collectedGold);
        validateNonNegativeValue(neededGold);

        handleGoldChanged(collectedGold, neededGold);
    }

    /**
     * Gets the parameters of an EntireMapUpdate event, and passes them onto the handler.
     * These parameters are validated in the process.
     */
    private void processEntireMapUpdate() throws IOException, IllegalArgumentException {
        Tile[][] newMap = new Tile[logic.getViewRadius()][logic.getViewRadius()];

        for (int i = 0; i < logic.getViewRadius(); i++) {
            for (int j = 0; j < logic.getViewRadius(); j++) {
                newMap[i][j] = Tile.valueOf(logic.connection.getEventByte());
                validateNonNullObject(newMap[i][j]);
            }
        }

        handleEntireMapUpdate(newMap);
    }

    /**
     * Gets the parameters of a MapRowUpdate event, and passes them onto the handler.
     * These parameters are validated in the process.
     */
    private void processMapRowUpdate() throws IOException, IllegalArgumentException {
        byte positionY = logic.connection.getEventByte();
        validateNonNegativeValue(positionY);

        Tile[] newRow = new Tile[logic.getViewRadius()];

        for (int i = 0; i < newRow.length; i++) {
            newRow[i] = Tile.valueOf(logic.connection.getEventByte());
            validateNonNullObject(newRow[i]);
        }

        handleMapRowUpdate(positionY, newRow);
    }

    /**
     * Gets the parameters of a MapColumnUpdate event, and passes them onto the handler.
     * These parameters are validated in the process.
     */
    private void processMapColumnUpdate() throws IOException, IllegalArgumentException {
        byte positionX = logic.connection.getEventByte();
        validateNonNegativeValue(positionX);

        Tile[] newColumn = new Tile[logic.getViewRadius()];

        for (int i = 0; i < newColumn.length; i++) {
            newColumn[i] = Tile.valueOf(logic.connection.getEventByte());
            validateNonNullObject(newColumn[i]);
        }

        handleMapColumnUpdate(positionX, newColumn);
    }

    /**
     * Gets the parameter of a ViewRadiusChanged event, and passes it onto the handler.
     * This parameter is validated in the process.
     */
    private void processViewRadiusChanged() throws IOException {
        handleViewRadiusChanged(logic.connection.getEventByte());
    }

    /**
     * Gets the parameter of a ViewRadiusChanged event, and passes it onto the handler.
     * This parameter is validated in the process.
     */
    private void processPlayerAlertRadiusChanged() throws IOException {
        handlePlayerAlertRadiusChanged(logic.connection.getEventByte());
    }

    /**
     * Gets the parameter of a GameFinished event, and passes it onto the handler.
     * This parameter is validated in the process.
     */
    private void processGameFinished() throws IOException {
        handleGameFinished(logic.connection.getEventByte());
    }

    /**
     * Handles a player moving into, or moving within your player alert radius.
     *
     * @param playerID
     *      The ID of the player that has moved.
     * @param positionX
     *      The player's new X coordinate, relative to your player alert view.
     * @param positionY
     *      The player's new Y coordinate, relative to your player alert view.
     */
    protected abstract void handlePlayerMoved(byte playerID, byte positionX, byte positionY);

    /**
     * Handles a player going out of range of your player alert radius.
     *
     * @param playerID
     *      The ID of the player that is now out of view.
     */
    protected abstract void handlePlayerOutOfView(byte playerID);

    /**
     * Handles a player's change of sprite.
     *
     * @param playerID
     *      The player ID to change.
     * @param character
     *      The player's new character.
     * @param sprite
     *      The player's new sprite.
     */
    protected abstract void handlePlayerSpriteChanged(byte playerID, Characters character, Sprites sprite);

    /**
     * Handles an update to a single tile in the visible map.
     *
     * @param positionX
     *      The new tile's X coordinate, relative to your view.
     * @param positionY
     *      The new tile's Y coordinate, relative to your view.
     * @param newTile
     *      The new tile.
     */
    protected abstract void handleTileChanged(byte positionX, byte positionY, Tile newTile);

    /**
     * Handles an update to the amount of gold on hand or needed to win.
     *
     * @param collectedGold
     *      The amount of gold you now have on hand.
     * @param neededGold
     *      The amount of gold needed to escape the dungeon.
     */
    protected abstract void handleGoldChanged(byte collectedGold, byte neededGold);

    /**
     * Handles an update to the entire visible map.
     *
     * @param newMap
     *      The new map. Contains all the tiles in your view.
     */
    protected abstract void handleEntireMapUpdate(Tile[][] newMap);

    /**
     * Handles an update to a row in the visible map.
     *
     * @param positionY
     *      The Y coordinate of the new row.
     * @param newRow
     *      The tiles in this new row, from left to right.
     */
    protected abstract void handleMapRowUpdate(byte positionY, Tile[] newRow);

    /**
     * Handles an update to a column in the visible map.
     *
     * @param positionX
     *      The X coordinate of the new column.
     * @param newColumn
     *      The tiles in this new column, from top to bottom.
     */
    protected abstract void handleMapColumnUpdate(byte positionX, Tile[] newColumn);

    /**
     * Handles a change in view radius. This will be sent when the game starts,
     * and whenever the view radius changes (e.g. when a flashlight is collected).
     *
     * If you are overriding this method, call super's implementation first.
     *
     * @param newViewRadius
     *      The new view radius.
     */
    protected void handleViewRadiusChanged(byte newViewRadius) {
        logic.setViewRadius(newViewRadius);
    };

    /**
     * Handles a change in player alert radius. This will be sent at the same time
     * as a change in view radius.
     *
     * If you are overriding this method, call super's implementation first.
     *
     * @param newPlayerAlertRadius
     *      The new player alert radius.
     */
    protected void handlePlayerAlertRadiusChanged(byte newPlayerAlertRadius) {
        logic.setPlayerAlertRadius(newPlayerAlertRadius);
    };

    /**
     * Handles the game finishing. This will be sent to all players when the game finishes.
     *
     * @param winningPlayer
     *      The player ID of the winning player.
     */
    protected abstract void handleGameFinished(byte winningPlayer);

    /**
     * Throws an exception if the value is negative.
     *
     * @param value
     *      The value to validate.
     * @throws IllegalArgumentException
     *      Thrown if value is negative.
     */
    private void validateNonNegativeValue(byte value) throws IllegalArgumentException {
        if (value < 0) {
            throw new IllegalArgumentException("An invalid argument was received.");
        }
    }

    /**
     * Throws an exception if positionX or positionY are negative.
     *
     * @param positionX
     *      The x-coordinate to validate.
     * @param positionY
     *      The y-coordinate to validate.
     * @throws IllegalArgumentException
     *      Thrown if either value is negative.
     */
    private void validatePosition(byte positionX, byte positionY) throws IllegalArgumentException {
        if (positionX < 0 || positionY < 0) {
            throw new IllegalArgumentException("An invalid argument was received");
        }
    }

    /**
     * Throws an exception if the given object is null.
     *
     * @param object
     *      The object to validate.
     * @throws IllegalArgumentException
     *      Thrown if object is null.
     */
    private void validateNonNullObject(Object object) throws IllegalArgumentException {
        if (object == null) {
            throw new IllegalArgumentException("An invalid argument was received.");
        }
    }

}

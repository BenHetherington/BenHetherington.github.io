import controller.ViewController;

/**
 * A simple class to start up the game.
 *
 * @author  Ben Hetherington
 * @version 1.1
 * @release 06/04/2016
 */
public class Main {

    /**
     * The starting point of Dungeon of Doom.
     * Creates a view controller, which sets up the UI.
     *
     * @param args
     *      The arguments passed to the program from the command line.
     */
    public static void main(String[] args) {
        System.setProperty("apple.laf.useScreenMenuBar", "true"); // Required to position the menu bar correctly on a Mac
        new ViewController();
    }

}

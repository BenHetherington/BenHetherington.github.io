package tests;

import static org.junit.Assert.*;

import client.ClientLogic;

import java.io.IOException;

public class TestClientLogic extends ClientLogic {

    public TestClientLogic() {
        eventHandler = new TestEventHandler(this);
    }

    public void handleCommunicationError(Exception cause) {
        if (isGameRunning()) {
            assertTrue("There was a communication error: " + cause, false);
        }
    }

    public void finishGame(byte winningPlayer) {
        try {
            connection.closeSocket();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package tests;

import client.EventHandler;
import common.Direction;
import common.Tile;
import view.player.Characters;
import view.player.Sprites;

import java.util.concurrent.CountDownLatch;

public class TestEventHandler extends EventHandler {

    public Tile[][] testMap = new Tile[5][5];
    public CountDownLatch latch = new CountDownLatch(0);

    public TestEventHandler(TestClientLogic logic) {
        super(logic);
    }

    @Override
    protected void handleTileChanged(byte positionX, byte positionY, Tile newTile) {

    }

    @Override
    protected void handlePlayerSpriteChanged(byte playerID, Characters character, Sprites sprite) {

    }

    @Override
    protected void handleMapColumnUpdate(byte positionX, Tile[] newColumn) {
        for (int i = 0; i < logic.getViewRadius(); i++) {
            testMap[i + 1][positionX + 1] = newColumn[i];
        }
    }

    @Override
    protected void handleGoldChanged(byte collectedGold, byte neededGold) {

    }

    @Override
    protected void handlePlayerOutOfView(byte playerID) {

    }

    @Override
    protected void handleMapRowUpdate(byte positionY, Tile[] newRow) {
        for (int i = 0; i < logic.getViewRadius(); i++) {
            testMap[positionY + 1][i + 1] = newRow[i];
        }
    }

    @Override
    protected void handleEntireMapUpdate(Tile[][] newMap) {
        testMap = new Tile[logic.getViewRadius() + 2][logic.getViewRadius() + 2];

        for (int i = 0; i < logic.getViewRadius(); i++) {
            System.arraycopy(newMap[i], 0, testMap[i + 1], 1, logic.getViewRadius());
        }
    }

    @Override
    protected void handleGameFinished(byte winningPlayer) {

    }

    @Override
    protected void handlePlayerMoved(byte playerID, byte positionX, byte positionY) {

    }

    public synchronized void shiftMapTiles(Direction direction) {
        latch = new CountDownLatch(1);
        switch (direction) {
            case Up:
                // If we walked up, we need to shift the map downwards
                for (int i = logic.getViewRadius(); i >= 0; i--) {
                    for (int j = 0; j < logic.getViewRadius() + 2; j++) {
                        Tile tile = testMap[i][j];
                        testMap[i + 1][j] = tile;
                    }
                }
                break;

            case Down:
                // If we walked down, we need to shift the map upwards
                for (int i = 1; i < logic.getViewRadius() + 2; i++) {
                    for (int j = 0; j < logic.getViewRadius() + 2; j++) {
                        Tile tile = testMap[i][j];
                        testMap[i - 1][j] = tile;
                    }
                }
                break;

            case Left:
                // If we walked left, we need to shift the map to the right
                for (int i = 0; i < logic.getViewRadius() + 2; i++) {
                    for (int j = logic.getViewRadius(); j >= 0; j--) {
                        Tile tile = testMap[i][j];
                        testMap[i][j + 1] = tile;
                    }
                }
                break;

            case Right:
                // If we walked right, we need to shift the map to the left
                for (int i = 0; i < logic.getViewRadius() + 2; i++) {
                    for (int j = 1; j < logic.getViewRadius() + 2; j++) {
                        Tile tile = testMap[i][j];
                        testMap[i][j - 1] = tile;
                    }
                }
                break;
        }
        latch.countDown();
    }

}

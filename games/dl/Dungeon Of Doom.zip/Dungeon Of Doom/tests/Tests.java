package tests;

import client.*;
import common.Direction;
import common.Tile;
import common.network.Result;
import server.*;
import server.logic.*;

import org.junit.*;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import static org.junit.Assert.*;

public class Tests {

    final private static String DEFAULT_ADDRESS = "localhost";
    final private static int DEFAULT_PORT = 40004;

    private Map map;

    private Server server;
    private ServerConnection serverConnection;
    private Player player;

    private ClientLogic clientLogic;
    private ClientConnection clientConnection;

    @Before
    public void setUpTest() throws IOException, InvalidMapException, InterruptedException, ReflectiveOperationException {
        map = new Map(new File("./maps/Default Map.dod"));
        server = new Server(DEFAULT_PORT, map);

        Thread serverThread = new Thread(new Runnable() {
            public void run() {
                server.run();
            }
        });
        serverThread.setName("Server Thread");
        serverThread.start();

        clientLogic = new TestClientLogic();
        clientLogic.connect(DEFAULT_ADDRESS, DEFAULT_PORT);

        Thread.sleep(50);

        Field serverConnectionField = server.getClass().getDeclaredField("connections");
        serverConnectionField.setAccessible(true);
        serverConnection = (ServerConnection)((Set<ServerConnection>)serverConnectionField.get(server)).toArray()[0];

        Field clientConnectionField = clientLogic.getClass().getSuperclass().getDeclaredField("connection");
        clientConnectionField.setAccessible(true);
        clientConnection = (ClientConnection)clientConnectionField.get(clientLogic);

        Field playerField = serverConnection.getClass().getDeclaredField("player");
        playerField.setAccessible(true);
        player = (Player)playerField.get(serverConnection);
    }

    @After
    public void finishTest() throws IOException {
        clientLogic.quit();
        server.stop();
    }

    @Test
    public void eventStreamTest() throws IOException {
        for (int i = 0; i < 0xE0; i++) {
            serverConnection.sendBytes(new byte[] {(byte)i});

            if (i % 0x10 == 0) {
                serverConnection.sendEvent(new byte[] {(byte)0xE4, (byte)1, (byte)2});
            }

            assertEquals((byte)i, clientConnection.getByte());
        }
    }

    @Test
    public void mapUpdateTest() throws InterruptedException, ReflectiveOperationException {
        player.setPosition(new Point(9, 3));
        GameLogic logic = server.getLogic();

        Field eventSenderField = logic.getClass().getDeclaredField("eventSender");
        eventSenderField.setAccessible(true);
        EventSender eventSender = (EventSender)eventSenderField.get(logic);

        Field eventHandlerField = clientLogic.getClass().getSuperclass().getDeclaredField("eventHandler");
        eventHandlerField.setAccessible(true);
        TestEventHandler eventHandler = (TestEventHandler)eventHandlerField.get(clientLogic);

        eventSender.sendEntireMapUpdate(player);
        assertTrue(checkMap(eventHandler, map, player.getOriginOfViewForVisibleArea()));

        eventHandler.shiftMapTiles(Direction.Right);
        assertEquals(clientLogic.move(Direction.Right), Result.Success);
        assertTrue(checkMap(eventHandler, map, player.getOriginOfViewForVisibleArea()));

        eventHandler.shiftMapTiles(Direction.Down);
        assertEquals(clientLogic.move(Direction.Down), Result.Success);
        assertTrue(checkMap(eventHandler, map, player.getOriginOfViewForVisibleArea()));
    }

    private boolean checkMap(TestEventHandler eventHandler, Map fullMap, Point playerOrigin) throws InterruptedException {
        Thread.sleep(50);
        eventHandler.latch.await();

        for (int i = 0; i < clientLogic.getViewRadius(); i++) {
            for (int j = 0; j < clientLogic.getViewRadius(); j++) {
                if (fullMap.lookAtTile(new Point(j + playerOrigin.x, i + playerOrigin.y)) != eventHandler.testMap[i + 1][j + 1]) {
                    return false;
                }
            }
        }

        return true;
    }

}
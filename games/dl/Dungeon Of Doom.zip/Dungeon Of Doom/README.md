Dungeon Of Doom
===============

Compiling from Source Code
-----------------------------------------
Since you have downloaded the Dungeon of Doom source code, you will need to compile it before it can be run.

 1. Make sure you have downloaded and installed the [Java Developer Kit](www.oracle.com/technetwork/java/javase/downloads/index.html).
 2. Start up a Terminal (or the Command Prompt), and navigate to the Dungeon of Doom directory.
 3. Compile the code by running `javac Main.java` (this only needs to be done the first time you start the game).
 4. Start Dungeon of Doom by running `java Main`.

For more information, read the Documentation document.

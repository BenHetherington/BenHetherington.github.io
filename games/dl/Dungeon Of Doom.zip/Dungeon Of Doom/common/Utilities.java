package common;

import javax.swing.*;
import java.lang.reflect.InvocationTargetException;

/**
 * Provides some handy methods that don't fit into any of the other common classes.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class Utilities {

    /**
     * Wraps SwingUtilities's invokeAndWait() method, providing default exception handlers.
     *
     * @param runnable
     *      The code to be run on the Swing thread.
     */
    public static void invokeOnSwingThreadAndWait(Runnable runnable) {
        try {
            SwingUtilities.invokeAndWait(runnable);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();

        } catch (InvocationTargetException e) {
            // This method shouldn't throw an exception, so hopefully this is unnecessary
            e.printStackTrace();
        }
    }

    public static String getWorkingDirectory() {
        return System.getProperty("user.dir");
    }

}

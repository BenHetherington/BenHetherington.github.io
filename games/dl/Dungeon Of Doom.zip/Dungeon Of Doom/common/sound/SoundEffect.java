package common.sound;

import java.io.File;

/**
 * Represents all the sound effects in Dungeon of Doom.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public enum SoundEffect {
    Pickup(new File("./SFX/Pickup.wav")),
    CantPickup(new File("./SFX/Can't Pickup.wav")),
    CantWalkIntoWalls(new File("./SFX/Can't Walk Into Walls.wav")),
    Win(new File("./SFX/Win.wav")),
    Lose(new File("./SFX/Lose.wav")),
    MoreGoldAppeared(new File("./SFX/More Gold Appeared.wav"));

    final public File path;

    /**
     * Constructs a sound effect.
     *
     * @param path
     *      The path to the sound effect.
     */
    SoundEffect(File path) {
        this.path = path;
    }
}

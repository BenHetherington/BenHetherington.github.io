package common.sound;

import javax.sound.sampled.*;
import java.io.*;
import java.nio.file.Files;
import java.util.*;

/**
 * A basic sound engine. At present, it only handles sound effects.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class SoundEngine {

    private static final boolean DEBUGGING_ENABLED = false;

    private Clip clip;
    private Map<SoundEffect, byte[]> sfxBuffer = new HashMap<>();

    public SoundEngine() {
        setUpBuffer();
    }

    private void setUpBuffer() {
        for (SoundEffect sfx : SoundEffect.values()) {
            try {
                byte[] data = Files.readAllBytes(sfx.path.toPath());
                sfxBuffer.put(sfx, data);

            } catch (IOException e) {
                if (DEBUGGING_ENABLED) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void playSound(SoundEffect sfx) {
        try {
            if (clip != null) {
                clip.close();
            }

            byte[] data = sfxBuffer.get(sfx);
            AudioInputStream inputStream = AudioSystem.getAudioInputStream(new ByteArrayInputStream(data));
            clip = AudioSystem.getClip();
            clip.open(inputStream);
            clip.start();

        } catch (UnsupportedAudioFileException | LineUnavailableException | IOException e) {
            if (DEBUGGING_ENABLED) {
                e.printStackTrace();
            }
        }
    }
}

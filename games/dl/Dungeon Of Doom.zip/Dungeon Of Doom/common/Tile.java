package common;

/**
 * Represents the possible in-game tiles.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public enum Tile {
    Empty('.'),
    Wall('#'),
    Gold('G'),
    Exit('E');

    final public char charValue;
    final public byte byteValue;

    /**
     * Retrieves the tile with the given char value.
     *
     * @param tileChar
     *      The value to use.
     * @return
     *      The tile that is represented by that value.
     */
    public static Tile valueOf(char tileChar) {
        for (Tile tile : Tile.values()) {
            if (tile.charValue == tileChar) {
                return tile;
            }
        }

        return null;
    }

    /**
     * Retrieves the tile with the given byte value.
     *
     * @param tileByte
     *      The value to use.
     * @return
     *      The tile that is represented by that value.
     */
    public static Tile valueOf(byte tileByte) {
        for (Tile tile : Tile.values()) {
            if (tile.byteValue == tileByte) {
                return tile;
            }
        }

        return null;
    }

    /**
     * Constructs a tile.
     *
     * @param value
     *      THe tile's value.
     */
    Tile(char value) {
        charValue = value;
        byteValue = (byte)value;
    }
}

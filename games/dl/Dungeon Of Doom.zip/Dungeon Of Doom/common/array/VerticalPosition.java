package common.array;

/**
 * Represents either Top or Bottom.
 */
public enum VerticalPosition {
    Top, Bottom
}

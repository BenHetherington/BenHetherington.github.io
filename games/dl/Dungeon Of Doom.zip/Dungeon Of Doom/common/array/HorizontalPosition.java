package common.array;

/**
 * Represents either Left or Right.
 */
public enum HorizontalPosition {
    Left, Right
}

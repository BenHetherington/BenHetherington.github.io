package common.array;

import java.util.*;

/**
 * Wraps an dynamically-sized 2D array, constructed using an ArrayList of ArrayLists.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 *
 * @param <E>
 *      The object type to be contained in this array.
 */
public class ArrayList2D<E> {

    private ArrayList<ArrayList<E>> array = new ArrayList<>();
    private DefaultElementCallback<E> defaultElement = getNullDefaultElement();

    /**
     * @return
     *      The array's height.
     */
    public int getHeight() {
        return array.size();
    }

    /**
     * @return
     *      The array's width.
     */
    public int getWidth() {
        if (array.size() > 0) {
            return array.get(0).size();
        } else {
            return 0;
        }
    }

    /**
     * Retrieves an object from the given coordinates.
     *
     * @param x
     *      The x-coordinate of the object.
     * @param y
     *      The y-coordinate of the object.
     * @return
     *      The retrieved object.
     */
    public synchronized E get(int x, int y) {
        return array.get(y).get(x);
    }

    /**
     * Sets an object at the given coordinates.
     *
     * @param x
     *      The x-coordinate to use.
     * @param y
     *      The y-coordinate to use.
     * @param element
     *      The object to be set at the given position.
     */
    public synchronized void set(int x, int y, E element) {
        array.get(y).set(x, element);
    }

    /**
     * Sets the default element callback; this callback is called whenever a filler value is needed
     * in a new row or column.
     *
     * @param defaultElement
     *      The callback to be used.
     */
    public synchronized void setDefaultElement(DefaultElementCallback<E> defaultElement) {
        this.defaultElement = defaultElement;
    }

    /**
     * Adds a new row.
     *
     * @param position
     *      Indicates if the row should be added to the top or bottom of the array.
     */
    public synchronized void addRow(VerticalPosition position) {
        int index;
        int width = getWidth();

        if (position == VerticalPosition.Top) {
            array.add(0, new ArrayList<E>());
            index = 0;

        } else {
            array.add(new ArrayList<E>());
            index = array.size() - 1;
        }

        for (int i = 0; i < width; i++) {
            array.get(index).add(defaultElement.getNextDefaultElement());
        }
    }

    /**
     * Removes a row.
     *
     * @param position
     *      Indicates if the row should be removed from the top or bottom of the array.
     */
    public synchronized void removeRow(VerticalPosition position) {
        if (position == VerticalPosition.Top) {
            array.remove(0);

        } else {
            array.remove(array.size() - 1);
        }
    }

    /**
     * Adds a column.
     *
     * @param position
     *      Indicates if the column should be added to the left or right of the array.
     */
    public synchronized void addColumn(HorizontalPosition position) {
        for (int i = 0; i < getHeight(); i++) {
            if (position == HorizontalPosition.Left) {
                array.get(i).add(0, defaultElement.getNextDefaultElement());

            } else {
                array.get(i).add(defaultElement.getNextDefaultElement());
            }
        }
    }

    /**
     * Removes a column.
     *
     * @param position
     *      Indicates if the colum should be removed from the left or right of the array.
     */
    public synchronized void removeColumn(HorizontalPosition position) {
        int index;
        if (position == HorizontalPosition.Left) {
            index = 0;
        } else {
            index = array.get(0).size() - 1;
        }

        for (int i = 0; i < getHeight(); i++) {
            array.get(i).remove(index);
        }
    }

    /**
     * Adds rows and columns to the array, to ensure that the array has the given dimensions.
     *
     * @param width
     *      The desired width of the array.
     * @param height
     *      The desired height of the array.
     */
    public synchronized void ensureDimensions(int width, int height) {
        if (width < 1 || height < 1) {
            throw new IllegalArgumentException("Dimensions must be positive.");
        }

        while (height > getHeight()) {
            addRow(VerticalPosition.Bottom);
        }

        while (height < getHeight()) {
            removeRow(VerticalPosition.Bottom);
        }

        while (width > getWidth()) {
            addColumn(HorizontalPosition.Right);
        }

        while (width < getWidth()) {
            removeColumn(HorizontalPosition.Right);
        }
    }

    /**
     * @return
     *      A default element callback that always returns null.
     */
    private DefaultElementCallback<E> getNullDefaultElement() {
        return new DefaultElementCallback<E>() {
            public E getNextDefaultElement() {
                return null;
            }
        };
    }

}

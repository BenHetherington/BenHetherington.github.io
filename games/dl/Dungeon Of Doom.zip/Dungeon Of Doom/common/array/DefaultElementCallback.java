package common.array;

/**
 * An interface for default element callbacks, for the 2DArrayList.
 *
 * @param <E>
 */
public interface DefaultElementCallback<E> {

    /**
     * @return
     *      The next default element.
     */
    E getNextDefaultElement();

}

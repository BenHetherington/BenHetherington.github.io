package common.network;

/**
 * Represents the responses that the server can send (in response to commands).
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public enum Result {

    Success((byte)0xA0),
    Fail((byte)0x20);

    public final byte value;

    /**
     * Retrieves the result with the given byte value.
     *
     * @param resultByte
     *      The value to use.
     * @return
     *      The result that is represented by that value.
     */
    public static Result valueOf(byte resultByte) {
        for (Result result : Result.values()) {
            if (result.value == resultByte) {
                return result;
            }
        }

        return null;
    }

    /**
     * Constructs a result.
     *
     * @param value
     *      THe result's value.
     */
    Result(byte value) {
        this.value = value;
    }

}

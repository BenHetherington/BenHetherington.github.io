package common.network;

/**
 * Represents the commands that can be sent by the client.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public enum Commands {

    MoveUp(0xF0),
    MoveDown(0xF1),
    MoveRight(0xF2),
    MoveLeft(0xF3),
    Pickup(0xF4),
    ChangeSprite(0xF5),
    Quit(0xFE);

    public final byte value;

    /**
     * Retrieves the command with the given byte value.
     *
     * @param commandByte
     *      The value to use.
     * @return
     *      The command that is represented by that value.
     */
    public static Commands valueOf(byte commandByte) {
        for (Commands command : Commands.values()) {
            if (command.value == commandByte) {
                return command;
            }
        }

        return null;
    }

    /**
     * Constructs a command.
     *
     * @param value
     *      THe command's value.
     */
    Commands(int value) {
        this.value = (byte)value;
    }

}

package common.network;

/**
 * Represents the events that can be sent by the server.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public enum Events {

    PlayerMoved(0xE0),
    PlayerOutOfView(0xE1),
    PlayerSpriteChanged(0xE2),
    TileChanged(0xE3),
    GoldChanged(0xE4),
    EntireMapUpdate(0xE5),
    MapRowUpdate(0xE6),
    MapColumnUpdate(0xE7),
    ViewRadiusChanged(0xE8),
    PlayerAlertRadiusChanged(0xE9),
    GameFinished(0xEF);

    public final byte value;

    /**
     * Retrieves the event with the given byte value.
     *
     * @param eventByte
     *      The value to use.
     * @return
     *      The event that is represented by that value.
     */
    public static Events valueOf(byte eventByte) {
        for (Events event : Events.values()) {
            if (event.value == eventByte) {
                return event;
            }
        }

        return null;
    }

    /**
     * Constructs an event.
     *
     * @param value
     *      THe event's value.
     */
    Events(int value) {
        this.value = (byte)value;
    }
}

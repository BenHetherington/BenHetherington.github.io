package common.image;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Map;

/**
 * Contains various image utilities, used throughout Dungeon of Doom.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class ImageUtilities {

    private ImageUtilities() {
        // Prevents an ImageUtilities object from being created
    }

    /**
     * Loads an image file.
     * If the image can't be found, it displays an error, and quits the program.
     *
     * @param file
     *      The file where the image is stored.
     * @return
     *      The loaded image.
     */
    public static BufferedImage loadImage(File file) {
        try {
            return ImageIO.read(file);

        } catch (IOException e) {
            String titleText = "Dungeon Of Doom";
            String messageText = "Dungeon of Doom cannot find or read the required graphics.\n" +
                    "To resolve this, try redownloading Dungeon of Doom.";
            String[] buttonText = new String[]{"Quit"};

            JOptionPane.showOptionDialog(null, messageText, titleText, JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, buttonText, buttonText[0]);
            System.exit(1);
            return new BufferedImage(0, 0, BufferedImage.TYPE_CUSTOM);
        }
    }

    /**
     * Scales the given image by a given integer.
     *
     * @param image
     *      The image to resize.
     * @param scale
     *      The scale factor to use; should be positive.
     * @return
     *      The resized image.
     */
    public static Image resizeImage(Image image, int scale) {
        if (scale > 1) {
            return image.getScaledInstance(image.getWidth(null) * scale, image.getHeight(null) * scale, Image.SCALE_FAST);
        } else {
            return image;
        }
    }

    /**
     * Recolours the given image, using the given map (between original to new colours)
     *
     * @param source
     *      The image to recolour.
     * @param recolourMap
     *      The map to use to recolour the image.
     * @return
     *      The recoloured image.
     */
    public static BufferedImage recolourImage(BufferedImage source, Map<Integer, Integer> recolourMap) {
        BufferedImage image = new BufferedImage(source.getWidth(), source.getHeight(), source.getType());

        for (int i = 0; i < source.getHeight(); i++) {
            for (int j = 0; j < source.getWidth(); j++) {
                int colour = source.getRGB(j, i);

                if (recolourMap.containsKey(colour)) {
                    colour = recolourMap.get(colour);
                }

                image.setRGB(j, i, colour);
            }
        }

        return image;
    }

    /**
     * Generates an image containing text.
     *
     * @param text
     *      The text to use.
     * @param width
     *      The width of the desired image.
     * @param height
     *      The height of the desired image.
     * @param size
     *      The text size to use.
     * @param background
     *      The colour of the backgroun.d
     * @param foreground
     *      The colour of the text.
     * @return
     *      The generated image.
     */
    public static BufferedImage generateTextImage(String text, int width, int height, float size, Color background, Color foreground) {
        // Based on http://stackoverflow.com/questions/10929524/how-to-add-text-to-an-image-in-java
        // and http://stackoverflow.com/questions/1055851/how-do-you-draw-a-string-centered-vertically-in-java

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        Graphics g = image.getGraphics();
        g.setColor(background);
        g.fillRect(0, 0, width, height);
        g.setColor(foreground);
        g.setFont(g.getFont().deriveFont(size));

        String[] lines = text.split("\n");

        FontMetrics metrics = g.getFontMetrics(g.getFont());
        int totalStringHeight = 0;

        for (String line : lines) {
            totalStringHeight += metrics.getStringBounds(line, g).getHeight();
        }

        int yOffset = (height - totalStringHeight) / 2  + (metrics.getAscent());

        for (String line : lines) {
            int xOffset = (int)(width - metrics.getStringBounds(line, g).getWidth()) / 2;
            g.drawString(line, xOffset, yOffset);
            yOffset += metrics.getStringBounds(line, g).getHeight();
        }

        g.dispose();

        return image;
    }

    /**
     * Converts a given Image into a BufferedImage.
     * From Java Game Engine: http://code.google.com/p/game-engine-for-java/source/browse/src/com/gej/util/ImageTool.java#31
     * Found at: http://stackoverflow.com/questions/13605248/java-converting-image-to-bufferedimage
     *
     * @param image
     *      The Image to be converted
     * @return
     *      The converted BufferedImage
     */
    public static BufferedImage toBufferedImage(Image image) {
        if (image instanceof BufferedImage) {
            return (BufferedImage)image;
        }

        // Create a buffered image with transparency
        BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_ARGB);

        // Draw the image on to the buffered image
        Graphics2D bGr = bufferedImage.createGraphics();
        bGr.drawImage(image, 0, 0, null);
        bGr.dispose();

        // Return the buffered image
        return bufferedImage;
    }

}

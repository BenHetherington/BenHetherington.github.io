package common.image;

public interface ImageFilenameCallback<E> {

    String getImageFilename(E element);

}

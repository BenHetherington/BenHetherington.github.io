package common.image;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;

/**
 * An image cache; stores and retrieves images.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 *
 * @param <E>
 *      The object to use as a key for retrieving images.
 */
public class ImageCache<E> {

    private Map<E, Image> imageCache = new HashMap<>();
    private ImageFilenameCallback<E> callback;
    private int scaleFactor;

    /**
     * Constructs a new image cache, with the given filename callback, and scale factor.
     *
     * @param callback
     * @param scaleFactor
     */
    public ImageCache(ImageFilenameCallback<E> callback, int scaleFactor) {
        this.callback = callback;
        this.scaleFactor = scaleFactor;
    }

    /**
     * Gets the graphic with the given key.
     *
     * @param element
     *      The key that represents the desired image.
     * @return
     *      The returned image.
     */
    public Image getGraphic(E element) {
        if (imageCache.containsKey(element)) {
            return imageCache.get(element);

        } else {
            File tileGraphicFile = new File(callback.getImageFilename(element));
            BufferedImage tileGraphic = ImageUtilities.loadImage(tileGraphicFile);
            Image scaledTile = ImageUtilities.resizeImage(tileGraphic, scaleFactor);
            imageCache.put(element, scaledTile);
            return scaledTile;
        }
    }

    /**
     * @return
     *      The scale factor used by this image cache.
     */
    public int getScaleFactor() {
        return scaleFactor;
    }

    /**
     * Clears the image cache.
     */
    public void reset() {
        imageCache.clear();
    }

}

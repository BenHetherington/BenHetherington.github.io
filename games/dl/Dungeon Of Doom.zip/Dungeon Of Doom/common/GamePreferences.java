package common;

import java.util.prefs.Preferences;

/**
 * Handles the storage and retrieval of game preferences.
 *
 * @author  Ben Hetherington
 * @version 1.0
 * @release 06/04/2016
 */
public class GamePreferences {

    final static private String NODE = "DungeonOfDoom-bdh25";
    final static private String GUI_SCALE_KEY = "GUIScale";
    final static private String INITIAL_SERVER_KEY = "InitialServer";
    final static private String INITIAL_PORT_KEY = "InitialPort";
    final static private String CONTROLS_SHOWN_KEY = "ControlsShown";

    /**
     * @return
     *      The scale of the game UI.
     */
    public static int getScale() {
        return getNode().getInt(GUI_SCALE_KEY, 3);
    }

    /**
     * Sets the scale of the game UI.
     *
     * @param scale
     *      The new scale.
     */
    public static void setScale(int scale) {
        getNode().putInt(GUI_SCALE_KEY, scale);
    }

    /**
     * @return
     *      The default value in the 'Join Game' server field.
     */
    public static String getInitialServer() {
        return getNode().get(INITIAL_SERVER_KEY, "localhost:40004");
    }

    /**
     * Sets the default value in the 'Join Game' server field.
     *
     * @param newValue
     *      The new default value.
     */
    public static void setInitialServer(String newValue) {
        getNode().put(INITIAL_SERVER_KEY, newValue);
    }

    /**
     * @return
     *      The default value in the 'Host Game' port field.
     */
    public static String getInitialPort() {
        return getNode().get(INITIAL_PORT_KEY, "40004");
    }

    /**
     * Sets the default value in the 'Host Game' port field.
     *
     * @param newValue
     *      The new default value.
     */
    public static void setInitialPort(String newValue) {
        getNode().put(INITIAL_PORT_KEY, newValue);
    }

    /**
     * @return
     *      True if the on-screen control panel should be shown.
     */
    public static boolean isControlsShown() {
        return getNode().getBoolean(CONTROLS_SHOWN_KEY, true);
    }

    /**
     * Sets if the on-screen control panel should be shown.
     *
     * @param newValue
     *      The new value.
     */
    public static void setControlsShown(boolean newValue) {
        getNode().putBoolean(CONTROLS_SHOWN_KEY, newValue);
    }

    /**
     * @return
     *      The Dungeon of Doom preferences node.
     */
    private static Preferences getNode() {
        return Preferences.userRoot().node(NODE);
    }

    private GamePreferences() {
        // To prevent a GamePreferences object from being created.
    }

}
